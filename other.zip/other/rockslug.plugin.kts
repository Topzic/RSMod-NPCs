package gg.rsmod.plugins.content.npcs.npcInfo.rockslug

arrayOf(Npcs.ROCKSLUG_421, Npcs.ROCKSLUG_422).forEach { rockslug ->
	set_combat_def(rockslug) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 27
			attack = 22
			strength = 27
			defence = 27
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1567
			block = 1565
			death = 1568
		 }

		slayerData {
			levelRequirement = 20
			xp = 27.00
		 }
	 }
}
