package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MYRE_BLAMISH_SNAIL, Npcs.MYRE_BLAMISH_SNAIL_2649).forEach { myreblamishsnail -> 
	set_combat_def(myreblamishsnail) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 8
			attack = 0
			strength = 0
			defence = 22
			magic = 1
			ranged = 5
		 }

		bonuses {
			attackBonus = 10
			strengthBonus = 10
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 5
			defenceSlash = 5
			defenceCrush = 30
			defenceMagic = 5
			defenceRanged = 50
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
