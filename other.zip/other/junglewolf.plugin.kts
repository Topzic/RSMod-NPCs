package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.JUNGLE_WOLF).forEach { junglewolf -> 
	set_combat_def(junglewolf) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 69
			attack = 50
			strength = 55
			defence = 52
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 6581
			block = 6578
			death = 6576
		 }

		slayerData {
			levelRequirement = 1
			xp = 70.00
		 }
	 }
}
