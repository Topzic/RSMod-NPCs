package gg.rsmod.plugins.content.npcs.npcInfo.darkwarrior

arrayOf(Npcs.DARK_WARRIOR, Npcs.DARK_WARRIOR_6606, Npcs.DARK_WARRIOR_11109, Npcs.DARK_WARRIOR_11110, Npcs.DARK_WARRIOR_11111).forEach { darkwarrior -> 
	set_combat_def(darkwarrior) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 17
			attack = 5
			strength = 5
			defence = 5
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 20
			strengthBonus = 16
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 96
			defenceSlash = 79
			defenceCrush = 59
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 17.00
		 }
	 }
}
