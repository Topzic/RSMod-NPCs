package gg.rsmod.plugins.content.npcs.npcInfo.countdraynor

arrayOf(Npcs.COUNT_DRAYNOR, Npcs.COUNT_DRAYNOR_3482, Npcs.COUNT_DRAYNOR_HARD, Npcs.COUNT_DRAYNOR_6393).forEach { countdraynor -> 
	set_combat_def(countdraynor) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 35
			attack = 30
			strength = 25
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 2
			defenceSlash = 1
			defenceCrush = 3
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 0.00
		 }
	 }
}
