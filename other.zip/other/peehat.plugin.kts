package gg.rsmod.plugins.content.npcs.npcInfo.peehat

arrayOf(Npcs.PEE_HAT).forEach { peehat -> 
	set_combat_def(peehat) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 120
			attack = 50
			strength = 100
			defence = 50
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 40
			magicDamageBonus = 0
			attackRanged = 40
			rangedStrengthBonus = 0
			defenceStab = 25
			defenceSlash = 25
			defenceCrush = 40
			defenceMagic = 200
			defenceRanged = 200
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 126.00
		 }
	 }
}
