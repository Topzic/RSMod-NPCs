package gg.rsmod.plugins.content.npcs.npcInfo.mountedterrorbirdgnome

arrayOf(Npcs.MOUNTED_TERRORBIRD_GNOME, Npcs.MOUNTED_TERRORBIRD_GNOME_2068, Npcs.MOUNTED_TERRORBIRD_GNOME_5971, Npcs.MOUNTED_TERRORBIRD_GNOME_5972, Npcs.MOUNTED_TERRORBIRD_GNOME_5973).forEach { mountedterrorbirdgnome -> 
	set_combat_def(mountedterrorbirdgnome) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 36
			attack = 25
			strength = 25
			defence = 25
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 16
			defenceSlash = 16
			defenceCrush = 18
			defenceMagic = 15
			defenceRanged = 10
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 36.00
		 }
	 }
}
