package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DAGANNOTH_140, Npcs.DAGANNOTH_970, Npcs.DAGANNOTH_971, Npcs.DAGANNOTH_972, Npcs.DAGANNOTH_973, Npcs.DAGANNOTH_974, Npcs.DAGANNOTH_975, Npcs.DAGANNOTH_976, Npcs.DAGANNOTH_977, Npcs.DAGANNOTH_978, Npcs.DAGANNOTH_979, Npcs.DAGANNOTH_3185, Npcs.DAGANNOTH_5942, Npcs.DAGANNOTH_5943, Npcs.DAGANNOTH_7259, Npcs.DAGANNOTH_7260).forEach { dagannoth ->
	set_combat_def(dagannoth) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 70
			attack = 68
			strength = 70
			defence = 50
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1341
			block = 1340
			death = 1342
		 }

		slayerData {
			levelRequirement = 0
			xp = 70.00
		 }
	 }
}
