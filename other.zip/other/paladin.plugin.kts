package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.PALADIN_1144, Npcs.PALADIN_3293, Npcs.PALADIN_3294, Npcs.PALADIN_8150, Npcs.PALADIN_8849, Npcs.PALADIN_8850, Npcs.PALADIN_8853).forEach { paladin -> 
	set_combat_def(paladin) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 66
			attack = 54
			strength = 54
			defence = 54
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 20
			strengthBonus = 22
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 87
			defenceSlash = 84
			defenceCrush = 76
			defenceMagic = 10
			defenceRanged = 79
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 151.80
		 }
	 }
}
