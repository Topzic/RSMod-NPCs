package gg.rsmod.plugins.content.npcs.npcInfo.chaoselemental

arrayOf(Npcs.CHAOS_ELEMENTAL_2054, Npcs.CHAOS_ELEMENTAL_JR, Npcs.CHAOS_ELEMENTAL_JR_5907, Npcs.CHAOS_ELEMENTAL_6505).forEach { chaoselemental -> 
	set_combat_def(chaoselemental) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 250
			attack = 270
			strength = 270
			defence = 270
			magic = 270
			ranged = 270
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 70
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 70
			defenceRanged = 70
		 }

		anims {
			attack = 3146
			block = 3145
			death = 3147
		 }

		slayerData {
			levelRequirement = 0
			xp = 268.75
		 }
	 }
}
