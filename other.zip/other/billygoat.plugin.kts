package gg.rsmod.plugins.content.npcs.npcInfo.billygoat

arrayOf(Npcs.BILLY_GOAT, Npcs.BILLY_GOAT_1797).forEach { billygoat -> 
	set_combat_def(billygoat) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 28
			attack = 31
			strength = 29
			defence = 29
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 30
			strengthBonus = 29
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 10
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
