package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DARK_BEAST_4005, Npcs.DARK_BEAST_7250, Npcs.REVENANT_DARK_BEAST, Npcs.CRYSTALLINE_DARK_BEAST, Npcs.CORRUPTED_DARK_BEAST).forEach { darkbeast -> 
	set_combat_def(darkbeast) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
		 }

		stats {
			hitpoints = 220
			attack = 140
			strength = 160
			defence = 120
			magic = 160
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 40
			defenceCrush = 100
			defenceMagic = 90
			defenceRanged = 100
		 }

		anims {
			attack = 2731
			block = 2732
			death = 2733
		 }

		slayerData {
			levelRequirement = 90
			xp = 225.40
		 }
	 }
}
