package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.KALRAG).forEach { kalrag -> 
	set_combat_def(kalrag) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 78
			attack = 78
			strength = 78
			defence = 78
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 17
			defenceCrush = 12
			defenceMagic = 13
			defenceRanged = 13
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
