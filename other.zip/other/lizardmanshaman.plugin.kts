package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.LIZARDMAN_SHAMAN, Npcs.LIZARDMAN_SHAMAN_6767, Npcs.LIZARDMAN_SHAMAN_7573, Npcs.LIZARDMAN_SHAMAN_7574, Npcs.LIZARDMAN_SHAMAN_7744, Npcs.LIZARDMAN_SHAMAN_7745, Npcs.LIZARDMAN_SHAMAN_8565).forEach { lizardmanshaman -> 
	set_combat_def(lizardmanshaman) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 150
			attack = 120
			strength = 120
			defence = 140
			magic = 130
			ranged = 120
		 }

		bonuses {
			attackBonus = 45
			strengthBonus = 38
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 45
			rangedStrengthBonus = 38
			defenceStab = 10
			defenceSlash = 40
			defenceCrush = 30
			defenceMagic = 50
			defenceRanged = 0
		 }

		anims {
			attack = 7192
			block = 7194
			death = 7196
		 }

		slayerData {
			levelRequirement = 0
			xp = 157.50
		 }
	 }
}
