package gg.rsmod.plugins.content.npcs.npcInfo.adamantdragon

arrayOf(Npcs.ADAMANT_DRAGON, Npcs.ADAMANT_DRAGON_8090).forEach { adamantdragon -> 
	set_combat_def(adamantdragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 12
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 295
			attack = 280
			strength = 280
			defence = 272
			magic = 186
			ranged = 186
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 110
			defenceCrush = 85
			defenceMagic = 30
			defenceRanged = 95
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 1
			xp = 324.50
		 }
	 }
}
