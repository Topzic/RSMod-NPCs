package gg.rsmod.plugins.content.npcs.npcInfo.karamel

arrayOf(Npcs.KARAMEL, Npcs.KARAMEL_HARD, Npcs.KARAMEL_6371).forEach { karamel -> 
	set_combat_def(karamel) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 250
			attack = 1
			strength = 1
			defence = 100
			magic = 1
			ranged = 100
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 134
			rangedStrengthBonus = 55
			defenceStab = 150
			defenceSlash = 150
			defenceCrush = 150
			defenceMagic = 150
			defenceRanged = 150
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
