package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.STUNTED_DEMONIC_GORILLA, Npcs.DEMONIC_GORILLA, Npcs.DEMONIC_GORILLA_7145, Npcs.DEMONIC_GORILLA_7146, Npcs.DEMONIC_GORILLA_7147, Npcs.DEMONIC_GORILLA_7148, Npcs.DEMONIC_GORILLA_7149, Npcs.DEMONIC_GORILLA_7152).forEach { demonicgorilla -> 
	set_combat_def(demonicgorilla) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 380
			attack = 205
			strength = 195
			defence = 200
			magic = 195
			ranged = 195
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 40
			magicDamageBonus = 0
			attackRanged = 43
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 50
			defenceCrush = 50
			defenceMagic = 50
			defenceRanged = 50
		 }

		anims {
			attack = 7226
			block = 7224
			death = 7229
		 }

		slayerData {
			levelRequirement = 1
			xp = 408.50
		 }
	 }
}
