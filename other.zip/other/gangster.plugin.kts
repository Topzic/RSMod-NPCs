package gg.rsmod.plugins.content.npcs.npcInfo.gangster

arrayOf(Npcs.GANGSTER, Npcs.GANGSTER_6897, Npcs.GANGSTER_6898, Npcs.GANGSTER_6899).forEach { gangster -> 
	set_combat_def(gangster) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 40
			attack = 40
			strength = 30
			defence = 50
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 20
			strengthBonus = 30
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 10
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
