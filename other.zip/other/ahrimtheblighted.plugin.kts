package gg.rsmod.plugins.content.npcs.npcInfo.ahrimtheblighted

arrayOf(Npcs.AHRIM_THE_BLIGHTED).forEach { ahrimtheblighted -> 
	set_combat_def(ahrimtheblighted) {

		configs {
			attackSpeed = 6
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 100
			attack = 1
			strength = 1
			defence = 100
			magic = 100
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 73
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 103
			defenceSlash = 85
			defenceCrush = 117
			defenceMagic = 73
			defenceRanged = 0
		 }

		anims {
			attack = 727
			block = 1
			death = 4167
		 }

		slayerData {
			levelRequirement = 1
			xp = 20.00
		 }
	 }
}
