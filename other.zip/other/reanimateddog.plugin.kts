package gg.rsmod.plugins.content.npcs.npcInfo.reanimateddog

arrayOf(Npcs.REANIMATED_DOG).forEach { reanimateddog -> 
	set_combat_def(reanimateddog) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 35
			attack = 35
			strength = 36
			defence = 37
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 15
			defenceSlash = 15
			defenceCrush = 15
			defenceMagic = 15
			defenceRanged = 15
		 }

		anims {
			attack = 6565
			block = 6563
			death = 6564
		 }

		slayerData {
			levelRequirement = 1
			xp = 520.00
		 }
	 }
}
