package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.SAN_TOJALON).forEach { santojalon -> 
	set_combat_def(santojalon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 120
			attack = 86
			strength = 84
			defence = 86
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 16
			magicDamageBonus = 0
			attackRanged = 16
			rangedStrengthBonus = 0
			defenceStab = 18
			defenceSlash = 22
			defenceCrush = 20
			defenceMagic = 1
			defenceRanged = 20
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
