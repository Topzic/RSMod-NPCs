package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CRAB, Npcs.CRAB_1553, Npcs.CRAB_4822, Npcs.CRAB_8733, Npcs.CRAB_9201, Npcs.CRAB_10563).forEach { crab ->
	set_combat_def(crab) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 18
			attack = 17
			strength = 17
			defence = 22
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1312
			block = 1313
			death = 1314
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
