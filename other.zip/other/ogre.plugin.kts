package gg.rsmod.plugins.content.npcs.npcInfo.ogre

arrayOf(Npcs.OGRE, Npcs.OGRE_2095, Npcs.OGRE_2096, Npcs.OGRE_2233, Npcs.OGRE_GUARD_4368, Npcs.OGRE_GUARD_4369, Npcs.OGRE_GUARD_4370, Npcs.OGRE_GUARD_4371, Npcs.OGRE_GUARD_4372).forEach { ogre ->
	set_combat_def(ogre) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 60
			attack = 43
			strength = 43
			defence = 43
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 22
			strengthBonus = 20
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 60.00
		 }
	 }
}
