package gg.rsmod.plugins.content.npcs.npcInfo.gadderanks

arrayOf(Npcs.GADDERANKS, Npcs.GADDERANKS_4484, Npcs.GADDERANKS_4485, Npcs.MARIA_GADDERANKS, Npcs.MARIA_GADDERANKS_9595, Npcs.RON_GADDERANKS, Npcs.RON_GADDERANKS_9597, Npcs.GADDERANKS_9635).forEach { gadderanks -> 
	set_combat_def(gadderanks) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 20
			attack = 20
			strength = 20
			defence = 70
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 10
			defenceMagic = 10
			defenceRanged = 10
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
