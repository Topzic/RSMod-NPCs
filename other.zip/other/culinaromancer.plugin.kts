package gg.rsmod.plugins.content.npcs.npcInfo.culinaromancer

arrayOf(Npcs.CULINAROMANCER, Npcs.CULINAROMANCER_4849, Npcs.CULINAROMANCER_4872, Npcs.CULINAROMANCER_4873, Npcs.CULINAROMANCER_4874, Npcs.CULINAROMANCER_4875, Npcs.CULINAROMANCER_4876, Npcs.CULINAROMANCER_4877, Npcs.CULINAROMANCER_4878, Npcs.CULINAROMANCER_4879, Npcs.CULINAROMANCER_HARD, Npcs.CULINAROMANCER_6368).forEach { culinaromancer -> 
	set_combat_def(culinaromancer) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 150
			attack = 10
			strength = 100
			defence = 10
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 10
			defenceMagic = 10
			defenceRanged = 10
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
