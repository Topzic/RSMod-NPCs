package gg.rsmod.plugins.content.npcs.npcInfo.nylocasvasilias

arrayOf(Npcs.NYLOCAS_VASILIAS, Npcs.NYLOCAS_VASILIAS_8355, Npcs.NYLOCAS_VASILIAS_8356, Npcs.NYLOCAS_VASILIAS_8357, Npcs.NYLOCAS_VASILIAS_10786, Npcs.NYLOCAS_VASILIAS_10787, Npcs.NYLOCAS_VASILIAS_10788, Npcs.NYLOCAS_VASILIAS_10789, Npcs.NYLOCAS_VASILIAS_10807, Npcs.NYLOCAS_VASILIAS_10808, Npcs.NYLOCAS_VASILIAS_10809, Npcs.NYLOCAS_VASILIAS_10810, Npcs.NYLOCAS_VASILIAS_11185).forEach { nylocasvasilias -> 
	set_combat_def(nylocasvasilias) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 1800
			attack = 160
			strength = 140
			defence = 50
			magic = 20
			ranged = 140
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 40
			attackMagic = 380
			magicDamageBonus = 460
			attackRanged = 0
			rangedStrengthBonus = 40
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 8097
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
