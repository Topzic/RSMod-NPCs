package gg.rsmod.plugins.content.npcs.npcInfo.mercenary

arrayOf(Npcs.MERCENARY, Npcs.MERCENARY_4657, Npcs.MERCENARY_4658, Npcs.MERCENARY_4659, Npcs.MERCENARY_4678, Npcs.MERCENARY_8213, Npcs.MERCENARY_8214, Npcs.MERCENARY_8215, Npcs.MERCENARY_10390).forEach { mercenary ->
	set_combat_def(mercenary) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 60
			attack = 32
			strength = 32
			defence = 39
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 9
			strengthBonus = 14
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 17
			defenceSlash = 15
			defenceCrush = 19
			defenceMagic = 3
			defenceRanged = 19
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
