package gg.rsmod.plugins.content.npcs.npcInfo.elvarg

arrayOf(Npcs.ELVARG, Npcs.ELVARG_HARD, Npcs.ELVARG_6349, Npcs.ELVARG_8033).forEach { elvarg -> 
	set_combat_def(elvarg) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 80
			attack = 70
			strength = 70
			defence = 70
			magic = 70
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 40
			defenceCrush = 40
			defenceMagic = 30
			defenceRanged = 20
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 0
			xp = 80.00
		 }
	 }
}
