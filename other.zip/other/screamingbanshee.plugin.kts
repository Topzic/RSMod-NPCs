package gg.rsmod.plugins.content.npcs.npcInfo.screamingbanshee

arrayOf(Npcs.SCREAMING_BANSHEE, Npcs.SCREAMING_TWISTED_BANSHEE).forEach { screamingbanshee ->
	set_combat_def(screamingbanshee) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 61
			attack = 65
			strength = 61
			defence = 56
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 13
			defenceSlash = 13
			defenceCrush = 13
			defenceMagic = 0
			defenceRanged = 13
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 15
			xp = 610.00
		 }
	 }
}
