package gg.rsmod.plugins.content.npcs.npcInfo.arrg

arrayOf(Npcs.ARRG, Npcs.ARRG_643, Npcs.ARRG_HARD, Npcs.ARRG_6392).forEach { arrg -> 
	set_combat_def(arrg) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 140
			attack = 70
			strength = 140
			defence = 40
			magic = 0
			ranged = 70
		 }

		bonuses {
			attackBonus = 60
			strengthBonus = 100
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 35
			defenceSlash = 60
			defenceCrush = 35
			defenceMagic = 200
			defenceRanged = 200
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 150.50
		 }
	 }
}
