package gg.rsmod.plugins.content.npcs.npcInfo.sergeantstrongstack

arrayOf(Npcs.SERGEANT_STRONGSTACK).forEach { sergeantstrongstack -> 
	set_combat_def(sergeantstrongstack) {

		configs {
			attackSpeed = 5
			respawnDelay = 72
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 128
			attack = 124
			strength = 118
			defence = 125
			magic = 50
			ranged = 50
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 6154
			block = 6155
			death = 6156
		 }

		slayerData {
			levelRequirement = 1
			xp = 128.00
		 }
	 }
}
