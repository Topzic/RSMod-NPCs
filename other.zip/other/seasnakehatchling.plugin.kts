package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.SEA_SNAKE_HATCHLING).forEach { seasnakehatchling -> 
	set_combat_def(seasnakehatchling) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 50
			attack = 60
			strength = 55
			defence = 50
			magic = 1
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 3538
			block = 3539
			death = 3540
		 }

		slayerData {
			levelRequirement = 40
			xp = 50.00
		 }
	 }
}
