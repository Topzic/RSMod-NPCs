package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BLACK_KNIGHT_TITAN, Npcs.BLACK_KNIGHT_TITAN_HARD, Npcs.BLACK_KNIGHT_TITAN_6360).forEach { blackknighttitan -> 
	set_combat_def(blackknighttitan) {

		configs {
			attackSpeed = 7
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 142
			attack = 91
			strength = 100
			defence = 91
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 27
			strengthBonus = 22
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 18
			defenceSlash = 27
			defenceCrush = 18
			defenceMagic = 1000
			defenceRanged = 1000
		 }

		anims {
			attack = 128
			block = 129
			death = 131
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
