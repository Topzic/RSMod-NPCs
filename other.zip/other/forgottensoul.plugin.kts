package gg.rsmod.plugins.content.npcs.npcInfo.forgottensoul

arrayOf(Npcs.FORGOTTEN_SOUL, Npcs.FORGOTTEN_SOUL_10524, Npcs.FORGOTTEN_SOUL_10525, Npcs.FORGOTTEN_SOUL_10526, Npcs.FORGOTTEN_SOUL_10534, Npcs.FORGOTTEN_SOUL_10535, Npcs.FORGOTTEN_SOUL_10536, Npcs.FORGOTTEN_SOUL_10537, Npcs.FORGOTTEN_SOUL_10544, Npcs.FORGOTTEN_SOUL_10545).forEach { forgottensoul -> 
	set_combat_def(forgottensoul) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 50
			attack = 8
			strength = 8
			defence = 12
			magic = 10
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 0
			xp = 10.00
		 }
	 }
}
