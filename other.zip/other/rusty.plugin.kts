package gg.rsmod.plugins.content.npcs.npcInfo.rusty

arrayOf(Npcs.RUSTY).forEach { rusty -> 
	set_combat_def(rusty) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 7
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 15
			defenceSlash = 15
			defenceCrush = 15
			defenceMagic = 15
			defenceRanged = 15
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 8.00
		 }
	 }
}
