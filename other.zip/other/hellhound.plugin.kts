package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.HELLHOUND_104, Npcs.HELLHOUND_105, Npcs.HELLHOUND_135, Npcs.HELLHOUND_3133, Npcs.HELLHOUND_7256, Npcs.HELLHOUND_7877).forEach { hellhound ->
	set_combat_def(hellhound) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 116
			attack = 105
			strength = 104
			defence = 102
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 6581
			block = 6578
			death = 6576
		 }

		slayerData {
			levelRequirement = 0
			xp = 116.00
		 }
	 }
}
