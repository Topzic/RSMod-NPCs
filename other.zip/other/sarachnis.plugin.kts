package gg.rsmod.plugins.content.npcs.npcInfo.sarachnis

arrayOf(Npcs.SARACHNIS).forEach { sarachnis ->
	set_combat_def(sarachnis) {

		configs {
			attackSpeed = 4
			respawnDelay = 10
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 400
			attack = 200
			strength = 240
			defence = 150
			magic = 150
			ranged = 300
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 15
			rangedStrengthBonus = 0
			defenceStab = 60
			defenceSlash = 40
			defenceCrush = 10
			defenceMagic = 150
			defenceRanged = 300
		 }

		anims {
			attack = 8147
			block = 1
			death = 8318
		 }

		slayerData {
			levelRequirement = 1
			xp = 430.00
		 }
	 }
}
