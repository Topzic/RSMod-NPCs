package gg.rsmod.plugins.content.npcs.npcInfo.guthantheinfested

arrayOf(Npcs.GUTHAN_THE_INFESTED).forEach { guthantheinfested -> 
	set_combat_def(guthantheinfested) {

		configs {
			attackSpeed = 5
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 100
			attack = 100
			strength = 100
			defence = 100
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 259
			defenceSlash = 257
			defenceCrush = 241
			defenceMagic = 11
			defenceRanged = 250
		 }

		anims {
			attack = 2080
			block = 2079
			death = 4167
		 }

		slayerData {
			levelRequirement = 1
			xp = 20.00
		 }
	 }
}
