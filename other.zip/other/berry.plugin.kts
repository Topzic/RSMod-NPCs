package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BERRY, Npcs.BERRY_4134, Npcs.BLURBERRY, Npcs.BERRY_7235).forEach { berry -> 
	set_combat_def(berry) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 90
			attack = 40
			strength = 90
			defence = 25
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 20
			strengthBonus = 20
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 10
			defenceMagic = 200
			defenceRanged = 200
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 90.00
		 }
	 }
}
