package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CAVE_GOBLIN_MINER, Npcs.CAVE_GOBLIN_MINER_5331, Npcs.CAVE_GOBLIN_MINER_5332, Npcs.CAVE_GOBLIN_MINER_5333, Npcs.CAVE_GOBLIN_MINER_5336, Npcs.CAVE_GOBLIN_MINER_5337, Npcs.CAVE_GOBLIN_MINER_5338, Npcs.CAVE_GOBLIN_MINER_5339).forEach { cavegoblinminer -> 
	set_combat_def(cavegoblinminer) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 10
			attack = 10
			strength = 12
			defence = 7
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 10.00
		 }
	 }
}
