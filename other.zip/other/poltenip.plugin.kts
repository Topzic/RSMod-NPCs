package gg.rsmod.plugins.content.npcs.npcInfo.poltenip

arrayOf(Npcs.POLTENIP).forEach { poltenip -> 
	set_combat_def(poltenip) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 22
			attack = 19
			strength = 18
			defence = 14
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 4
			magicDamageBonus = 0
			attackRanged = 4
			rangedStrengthBonus = 0
			defenceStab = 18
			defenceSlash = 25
			defenceCrush = 19
			defenceMagic = 4
			defenceRanged = 20
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
