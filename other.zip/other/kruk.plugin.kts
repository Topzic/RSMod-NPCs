package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.KRUK, Npcs.KRUK_6804, Npcs.KRUK_6805, Npcs.KRUK_7099).forEach { kruk -> 
	set_combat_def(kruk) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 210
			attack = 130
			strength = 153
			defence = 150
			magic = 130
			ranged = 170
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 160
			magicDamageBonus = 0
			attackRanged = 150
			rangedStrengthBonus = 0
			defenceStab = 100
			defenceSlash = 100
			defenceCrush = 100
			defenceMagic = 250
			defenceRanged = 100
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
