package gg.rsmod.plugins.content.npcs.npcInfo.grip

arrayOf(Npcs.GRIP).forEach { grip -> 
	set_combat_def(grip) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 25
			attack = 18
			strength = 17
			defence = 18
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 5
			magicDamageBonus = 0
			attackRanged = 5
			rangedStrengthBonus = 0
			defenceStab = 16
			defenceSlash = 27
			defenceCrush = 22
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
