package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ANIMATED_BRONZE_ARMOUR).forEach { animatedbronzearmour -> 
	set_combat_def(animatedbronzearmour) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 10
			attack = 10
			strength = 10
			defence = 10
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 4
			magicDamageBonus = 0
			attackRanged = 4
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 25
			defenceCrush = 19
			defenceMagic = 400
			defenceRanged = 400
		 }

		anims {
			attack = 386
			block = 388
			death = 4167
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
