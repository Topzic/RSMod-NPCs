package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BARBARIAN, Npcs.BARBARIAN_3056, Npcs.BARBARIAN_3057, Npcs.BARBARIAN_3058, Npcs.BARBARIAN_3059, Npcs.BARBARIAN_3060, Npcs.BARBARIAN_3061, Npcs.BARBARIAN_3062, Npcs.BARBARIAN_3064, Npcs.BARBARIAN_3065, Npcs.BARBARIAN_3066, Npcs.BARBARIAN_3067, Npcs.BARBARIAN_3068, Npcs.BARBARIAN_3069, Npcs.BARBARIAN_3070, Npcs.BARBARIAN_3071, Npcs.BARBARIAN_3072, Npcs.BARBARIAN_3256, Npcs.BARBARIAN_3262, Npcs.BARBARIAN_10676, Npcs.BARBARIAN_10677, Npcs.BARBARIAN_10678, Npcs.BARBARIAN_10679, Npcs.BARBARIAN_10984, Npcs.BARBARIAN_10985, Npcs.BARBARIAN_10986, Npcs.BARBARIAN_10987, Npcs.BARBARIAN_10988).forEach { barbarian ->
	set_combat_def(barbarian) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 14
			attack = 6
			strength = 5
			defence = 5
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 8
			strengthBonus = 10
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 1
			defenceSlash = 1
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
