package gg.rsmod.plugins.content.npcs.npcInfo.banditchampion

arrayOf(Npcs.BANDIT_CHAMPION).forEach { banditchampion -> 
	set_combat_def(banditchampion) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 50
			attack = 59
			strength = 80
			defence = 50
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 9
			magicDamageBonus = 0
			attackRanged = 9
			rangedStrengthBonus = 0
			defenceStab = 9
			defenceSlash = 8
			defenceCrush = 10
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 370.00
		 }
	 }
}
