package gg.rsmod.plugins.content.npcs.npcInfo.ankou

arrayOf(Npcs.ANKOU, Npcs.ANKOU_2515, Npcs.ANKOU_2516, Npcs.ANKOU_2517, Npcs.ANKOU_2518, Npcs.ANKOU_2519, Npcs.ANKOU_6608, Npcs.ANKOU_7257, Npcs.ANKOU_7864).forEach { ankou ->
	set_combat_def(ankou) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 60
			attack = 70
			strength = 70
			defence = 60
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 12.00
		 }
	 }
}
