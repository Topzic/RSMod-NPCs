package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MOGRE_2592, Npcs.MOGRE_GUARD).forEach { mogre -> 
	set_combat_def(mogre) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 244
			attack = 58
			strength = 55
			defence = 48
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 22
			magicDamageBonus = 0
			attackRanged = 22
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 359
			block = 360
			death = 361
		 }

		slayerData {
			levelRequirement = 0
			xp = 48.00
		 }
	 }
}
