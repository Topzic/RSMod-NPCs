package gg.rsmod.plugins.content.npcs.npcInfo.ferociousbarbarianspirit

arrayOf(Npcs.FEROCIOUS_BARBARIAN_SPIRIT).forEach { ferociousbarbarianspirit -> 
	set_combat_def(ferociousbarbarianspirit) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 190
			attack = 150
			strength = 140
			defence = 100
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 9
			magicDamageBonus = 0
			attackRanged = 9
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 73
			defenceCrush = 72
			defenceMagic = 3
			defenceRanged = 72
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 38.00
		 }
	 }
}
