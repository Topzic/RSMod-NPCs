package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.LYNX, Npcs.LYNX_11069, Npcs.LYNX_11070, Npcs.LYNX_TAMER, Npcs.LYNX_TAMER_11196, Npcs.LYNX_11197).forEach { lynx -> 
	set_combat_def(lynx) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 25
			attack = 18
			strength = 16
			defence = 18
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
