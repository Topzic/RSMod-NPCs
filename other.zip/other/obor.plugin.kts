package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.OBOR).forEach { obor -> 
	set_combat_def(obor) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 120
			attack = 90
			strength = 100
			defence = 60
			magic = 1
			ranged = 120
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 100
			magicDamageBonus = 0
			attackRanged = 100
			rangedStrengthBonus = 0
			defenceStab = 35
			defenceSlash = 40
			defenceCrush = 45
			defenceMagic = 20
			defenceRanged = 20
		 }

		anims {
			attack = 4666
			block = 4665
			death = 4668
		 }

		slayerData {
			levelRequirement = 1
			xp = 129.00
		 }
	 }
}
