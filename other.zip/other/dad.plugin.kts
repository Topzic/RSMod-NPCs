package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DAD, Npcs.DAD_HARD, Npcs.DAD_6391).forEach { dad -> 
	set_combat_def(dad) {

		configs {
			attackSpeed = 8
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 120
			attack = 60
			strength = 120
			defence = 50
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 40
			strengthBonus = 70
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 25
			defenceSlash = 25
			defenceCrush = 40
			defenceMagic = 200
			defenceRanged = 200
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 126.00
		 }
	 }
}
