package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BASILISK_KNIGHT_9293).forEach { basiliskknight -> 
	set_combat_def(basiliskknight) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 300
			attack = 186
			strength = 186
			defence = 186
			magic = 186
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 30
			defenceCrush = 0
			defenceMagic = 30
			defenceRanged = 0
		 }

		anims {
			attack = 8499
			block = 1
			death = 8501
		 }

		slayerData {
			levelRequirement = 60
			xp = 300.00
		 }
	 }
}
