package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DEADLY_RED_SPIDER).forEach { deadlyredspider -> 
	set_combat_def(deadlyredspider) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 35
			attack = 30
			strength = 25
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 15
			defenceSlash = 16
			defenceCrush = 7
			defenceMagic = 12
			defenceRanged = 16
		 }

		anims {
			attack = 5319
			block = 5320
			death = 5321
		 }

		slayerData {
			levelRequirement = 1
			xp = 35.00
		 }
	 }
}
