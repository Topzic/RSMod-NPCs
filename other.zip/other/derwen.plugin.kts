package gg.rsmod.plugins.content.npcs.npcInfo.derwen

arrayOf(Npcs.DERWEN, Npcs.DERWEN_7859, Npcs.DERWEN_9154).forEach { derwen -> 
	set_combat_def(derwen) {

		configs {
			attackSpeed = 6
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 320
			attack = 250
			strength = 150
			defence = 100
			magic = 180
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 80
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 200
			defenceSlash = 200
			defenceCrush = 200
			defenceMagic = 60
			defenceRanged = 200
		 }

		anims {
			attack = 7848
			block = 7846
			death = 7850
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
