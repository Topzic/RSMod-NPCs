package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.JOGRE_2234, Npcs.JOGRE_CHAMPION).forEach { jogrechampion ->
	set_combat_def(jogrechampion) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 120
			attack = 86
			strength = 86
			defence = 86
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 2935
			block = 2937
			death = 2938
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
