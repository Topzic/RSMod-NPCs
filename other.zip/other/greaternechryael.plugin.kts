package gg.rsmod.plugins.content.npcs.npcInfo.greaternechryael

arrayOf(Npcs.GREATER_NECHRYAEL, Npcs.GREATER_NECHRYAEL_11240).forEach { greaternechryael -> 
	set_combat_def(greaternechryael) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 205
			attack = 197
			strength = 197
			defence = 85
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 50
			defenceCrush = 50
			defenceMagic = 0
			defenceRanged = 50
		 }

		anims {
			attack = 1528
			block = 1531
			death = 1530
		 }

		slayerData {
			levelRequirement = 80
			xp = 210.00
		 }
	 }
}
