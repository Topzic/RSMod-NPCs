package gg.rsmod.plugins.content.npcs.npcInfo.bat

arrayOf(Npcs.ALBINO_BAT, Npcs.BAT, Npcs.GUANIC_BAT, Npcs.PRAEL_BAT, Npcs.GIRAL_BAT, Npcs.PHLUXIA_BAT, Npcs.KRYKET_BAT, Npcs.MURNG_BAT, Npcs.PSYKK_BAT, Npcs.BAT_9641, Npcs.BAT_9642, Npcs.BAT_10888).forEach { bat ->
	set_combat_def(bat) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 8
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 4915
			block = 4916
			death = 4917
		 }

		slayerData {
			levelRequirement = 1
			xp = 8.00
		 }
	 }
}
