package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GNOME_MAGE).forEach { gnomemage -> 
	set_combat_def(gnomemage) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 10
			attack = 3
			strength = 1
			defence = 1
			magic = 1
			ranged = 5
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 30
			defenceCrush = 30
			defenceMagic = 30
			defenceRanged = 30
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
