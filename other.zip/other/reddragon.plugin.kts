package gg.rsmod.plugins.content.npcs.npcInfo.reddragon

arrayOf(Npcs.RED_DRAGON, Npcs.RED_DRAGON_248, Npcs.RED_DRAGON_249, Npcs.RED_DRAGON_250, Npcs.RED_DRAGON_251, Npcs.RED_DRAGON_8075, Npcs.RED_DRAGON_8078, Npcs.RED_DRAGON_8079).forEach { reddragon ->
	set_combat_def(reddragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 140
			attack = 130
			strength = 130
			defence = 130
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 60
			defenceRanged = 50
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 143.40
		 }
	 }
}
