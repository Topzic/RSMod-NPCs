package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.EARTH_ELEMENTAL, Npcs.EARTH_ELEMENTAL_1367).forEach { earthelemental -> 
	set_combat_def(earthelemental) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 35
			attack = 20
			strength = 35
			defence = 35
			magic = 10
			ranged = 30
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
