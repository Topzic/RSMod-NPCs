package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GREATER_DEMON, Npcs.GREATER_DEMON_2026, Npcs.GREATER_DEMON_2027, Npcs.GREATER_DEMON_2028, Npcs.GREATER_DEMON_2029, Npcs.GREATER_DEMON_2030, Npcs.GREATER_DEMON_2031, Npcs.GREATER_DEMON_2032, Npcs.GREATER_DEMON_7244, Npcs.GREATER_DEMON_7245, Npcs.GREATER_DEMON_7246, Npcs.GREATER_DEMON_7871, Npcs.GREATER_DEMON_7872, Npcs.GREATER_DEMON_7873).forEach { greaterdemon -> 
	set_combat_def(greaterdemon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 87
			attack = 76
			strength = 78
			defence = 81
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 10
			defenceRanged = 0
		 }

		anims {
			attack = 64
			block = 65
			death = 67
		 }

		slayerData {
			levelRequirement = 0
			xp = 87.00
		 }
	 }
}
