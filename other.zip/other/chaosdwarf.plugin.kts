package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CHAOS_DWARF, Npcs.CHAOS_DWARF_2423).forEach { chaosdwarf -> 
	set_combat_def(chaosdwarf) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 61
			attack = 38
			strength = 42
			defence = 28
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 13
			magicDamageBonus = 0
			attackRanged = 13
			rangedStrengthBonus = 0
			defenceStab = 40
			defenceSlash = 34
			defenceCrush = 25
			defenceMagic = 10
			defenceRanged = 35
		 }

		anims {
			attack = 99
			block = 100
			death = 102
		 }

		slayerData {
			levelRequirement = 1
			xp = 61.00
		 }
	 }
}
