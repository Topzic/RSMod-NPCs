package gg.rsmod.plugins.content.npcs.npcInfo.colonelradick

arrayOf(Npcs.COLONEL_RADICK).forEach { colonelradick -> 
	set_combat_def(colonelradick) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 65
			attack = 25
			strength = 25
			defence = 25
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 9
			magicDamageBonus = 0
			attackRanged = 9
			rangedStrengthBonus = 0
			defenceStab = 39
			defenceSlash = 31
			defenceCrush = 34
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
