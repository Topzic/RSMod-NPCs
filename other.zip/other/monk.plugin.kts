package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MONK, Npcs.MONK_543, Npcs.MONK_544, Npcs.MONK_545, Npcs.MONK_553, Npcs.MONK_554, Npcs.MONK_555, Npcs.MONK_556, Npcs.MONK_1159, Npcs.MONK_1171, Npcs.MONK_2579, Npcs.MONK_4068, Npcs.MONK_4246, Npcs.MONK_4563, Npcs.MONK_4566, Npcs.MONK_4567, Npcs.MONK_6956).forEach { monk ->
	set_combat_def(monk) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 5
			attack = 2
			strength = 2
			defence = 3
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
