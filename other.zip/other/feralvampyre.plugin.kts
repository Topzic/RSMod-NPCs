package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.FERAL_VAMPYRE, Npcs.FERAL_VAMPYRE_3234, Npcs.FERAL_VAMPYRE_3237, Npcs.FERAL_VAMPYRE_3239, Npcs.FERAL_VAMPYRE_3707, Npcs.FERAL_VAMPYRE_3708, Npcs.FERAL_VAMPYRE_4431, Npcs.FERAL_VAMPYRE_5640, Npcs.FERAL_VAMPYRE_5641, Npcs.FERAL_VAMPYRE_5642, Npcs.FERAL_VAMPYRE_8678).forEach { feralvampyre -> 
	set_combat_def(feralvampyre) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 40
			attack = 55
			strength = 60
			defence = 55
			magic = 40
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 0
			xp = 40.00
		 }
	 }
}
