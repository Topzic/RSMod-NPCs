package gg.rsmod.plugins.content.npcs.npcInfo.outlaw

arrayOf(Npcs.OUTLAW, Npcs.OUTLAW_4168, Npcs.OUTLAW_4169, Npcs.OUTLAW_4170, Npcs.OUTLAW_4171, Npcs.OUTLAW_4172, Npcs.OUTLAW_4173, Npcs.OUTLAW_4174, Npcs.OUTLAW_4175, Npcs.OUTLAW_4176).forEach { outlaw -> 
	set_combat_def(outlaw) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 20
			attack = 35
			strength = 25
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 390
			block = 388
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
