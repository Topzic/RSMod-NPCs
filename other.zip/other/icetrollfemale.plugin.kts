package gg.rsmod.plugins.content.npcs.npcInfo.icetrollfemale

arrayOf(Npcs.ICE_TROLL_FEMALE, Npcs.ICE_TROLL_FEMALE_5825, Npcs.ICE_TROLL_FEMALE_5830).forEach { icetrollfemale -> 
	set_combat_def(icetrollfemale) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 80
			attack = 80
			strength = 80
			defence = 40
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 60
			magicDamageBonus = 0
			attackRanged = 60
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 60
			defenceCrush = 30
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 84.00
		 }
	 }
}
