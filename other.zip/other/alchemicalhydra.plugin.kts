package gg.rsmod.plugins.content.npcs.npcInfo.alchemicalhydra

arrayOf(Npcs.ALCHEMICAL_HYDRA, Npcs.ALCHEMICAL_HYDRA_8616, Npcs.ALCHEMICAL_HYDRA_8617, Npcs.ALCHEMICAL_HYDRA_8618, Npcs.ALCHEMICAL_HYDRA_8619, Npcs.ALCHEMICAL_HYDRA_8620, Npcs.ALCHEMICAL_HYDRA_8621, Npcs.ALCHEMICAL_HYDRA_8622, Npcs.ALCHEMICAL_HYDRA_8634).forEach { alchemicalhydra -> 
	set_combat_def(alchemicalhydra) {

		configs {
			attackSpeed = 4
			respawnDelay = 18
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 1100
			attack = 100
			strength = 100
			defence = 100
			magic = 260
			ranged = 260
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 45
			magicDamageBonus = 20
			attackRanged = 45
			rangedStrengthBonus = 20
			defenceStab = 75
			defenceSlash = 150
			defenceCrush = 150
			defenceMagic = 150
			defenceRanged = 45
		 }

		anims {
			attack = 8234
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 95
			xp = 132.00
		 }
	 }
}
