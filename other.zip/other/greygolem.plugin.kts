package gg.rsmod.plugins.content.npcs.npcInfo.greygolem

arrayOf(Npcs.GREY_GOLEM).forEach { greygolem -> 
	set_combat_def(greygolem) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 80
			attack = 80
			strength = 30
			defence = 80
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 300
			defenceSlash = 1
			defenceCrush = 300
			defenceMagic = 300
			defenceRanged = 300
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
