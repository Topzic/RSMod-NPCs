package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GNOME_TROOP, Npcs.GNOME_TROOP_4974, Npcs.GNOME_TROOP_5966, Npcs.GNOME_TROOP_5967).forEach { gnometroop -> 
	set_combat_def(gnometroop) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 3
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 2
			strengthBonus = 3
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 2
			defenceStab = 3
			defenceSlash = 4
			defenceCrush = 5
			defenceMagic = 2
			defenceRanged = 4
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
