package gg.rsmod.plugins.content.npcs.npcInfo.icespider

arrayOf(Npcs.ICE_SPIDER, Npcs.ICE_SPIDER_10722).forEach { icespider -> 
	set_combat_def(icespider) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 65
			attack = 50
			strength = 55
			defence = 43
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 17
			defenceCrush = 12
			defenceMagic = 13
			defenceRanged = 13
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 65.00
		 }
	 }
}
