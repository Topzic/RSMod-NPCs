package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.KHAZARD_TROOPER, Npcs.KHAZARD_TROOPER_4970, Npcs.KHAZARD_TROOPER_5964, Npcs.KHAZARD_TROOPER_5965).forEach { khazardtrooper -> 
	set_combat_def(khazardtrooper) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 22
			attack = 17
			strength = 18
			defence = 12
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 8
			strengthBonus = 10
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 33
			defenceSlash = 34
			defenceCrush = 29
			defenceMagic = 7
			defenceRanged = 33
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
