package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DEATHLY_RANGER).forEach { deathlyranger -> 
	set_combat_def(deathlyranger) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 120
			attack = 1
			strength = 1
			defence = 155
			magic = 155
			ranged = 210
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 120
			rangedStrengthBonus = 70
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 426
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 0.00
		 }
	 }
}
