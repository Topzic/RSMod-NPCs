package gg.rsmod.plugins.content.npcs.npcInfo.battlemage

arrayOf(Npcs.BATTLE_MAGE, Npcs.BATTLE_MAGE_1611, Npcs.BATTLE_MAGE_1612).forEach { battlemage -> 
	set_combat_def(battlemage) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 120
			attack = 1
			strength = 1
			defence = 1
			magic = 50
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 198
			block = 193
			death = 197
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
