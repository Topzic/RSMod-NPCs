package gg.rsmod.plugins.content.npcs.npcInfo.reanimatedminotaur

arrayOf(Npcs.REANIMATED_MINOTAUR).forEach { reanimatedminotaur -> 
	set_combat_def(reanimatedminotaur) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 10
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 5
			defenceSlash = 5
			defenceCrush = 5
			defenceMagic = 5
			defenceRanged = 5
		 }

		anims {
			attack = 4266
			block = 4267
			death = 4265
		 }

		slayerData {
			levelRequirement = 1
			xp = 364.00
		 }
	 }
}
