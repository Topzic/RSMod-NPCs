package gg.rsmod.plugins.content.npcs.npcInfo.otherworldlybeing

arrayOf(Npcs.OTHERWORLDLY_BEING).forEach { otherworldlybeing -> 
	set_combat_def(otherworldlybeing) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 66
			attack = 56
			strength = 56
			defence = 46
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 15
			defenceSlash = 10
			defenceCrush = 20
			defenceMagic = 5
			defenceRanged = 15
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 13.00
		 }
	 }
}
