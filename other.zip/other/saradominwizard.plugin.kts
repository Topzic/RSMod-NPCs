package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.SARADOMIN_WIZARD).forEach { saradominwizard -> 
	set_combat_def(saradominwizard) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 120
			attack = 100
			strength = 80
			defence = 80
			magic = 80
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 40
			magicDamageBonus = 0
			attackRanged = 40
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 30
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
