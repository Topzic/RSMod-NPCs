package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.REANIMATED_DEMON_SPAWN).forEach { reanimateddemonspawn -> 
	set_combat_def(reanimateddemonspawn) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 70
			attack = 90
			strength = 90
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 10
			defenceRanged = 0
		 }

		anims {
			attack = 64
			block = 65
			death = 67
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
