package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BRAWLER, Npcs.BRAWLER_1735, Npcs.BRAWLER_1736, Npcs.BRAWLER_1737, Npcs.BRAWLER_1738).forEach { brawler -> 
	set_combat_def(brawler) {

		configs {
			attackSpeed = 4
			respawnDelay = 78
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 53
			attack = 27
			strength = 57
			defence = 43
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 3897
			block = 3895
			death = 3894
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
