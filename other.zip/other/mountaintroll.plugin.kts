package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MOUNTAIN_TROLL, Npcs.MOUNTAIN_TROLL_937, Npcs.MOUNTAIN_TROLL_938, Npcs.MOUNTAIN_TROLL_939, Npcs.MOUNTAIN_TROLL_940, Npcs.MOUNTAIN_TROLL_941, Npcs.MOUNTAIN_TROLL_942, Npcs.MOUNTAIN_TROLL_4143).forEach { mountaintroll -> 
	set_combat_def(mountaintroll) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 90
			attack = 40
			strength = 75
			defence = 40
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 20
			strengthBonus = 20
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 10
			defenceMagic = 200
			defenceRanged = 200
		 }

		anims {
			attack = 284
			block = 285
			death = 287
		 }

		slayerData {
			levelRequirement = 0
			xp = 90.00
		 }
	 }
}
