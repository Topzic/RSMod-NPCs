package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MOURNER, Npcs.MOURNER_8844, Npcs.MOURNER_8845, Npcs.MOURNER_8846, Npcs.HEAD_MOURNER, Npcs.MOURNER_8970, Npcs.MOURNER_8971, Npcs.MOURNER_8972, Npcs.MOURNER_8975, Npcs.MOURNER_8999, Npcs.MOURNER_9000, Npcs.MOURNER_9003, Npcs.MOURNER_9004, Npcs.MOURNER_9007, Npcs.MOURNER_9008, Npcs.MOURNER_9009, Npcs.MOURNER_9010, Npcs.MOURNER_9013, Npcs.MOURNER_9017, Npcs.MOURNER_9018).forEach { mourner -> 
	set_combat_def(mourner) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 19
			attack = 95
			strength = 95
			defence = 80
			magic = 1
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 60
			defenceRanged = 50
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 107.50
		 }
	 }
}
