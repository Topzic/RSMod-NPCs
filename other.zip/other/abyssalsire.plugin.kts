package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ABYSSAL_SIRE, Npcs.ABYSSAL_SIRE_5887, Npcs.ABYSSAL_SIRE_5888, Npcs.ABYSSAL_SIRE_5889, Npcs.ABYSSAL_SIRE_5890, Npcs.ABYSSAL_SIRE_5891, Npcs.ABYSSAL_SIRE_5908).forEach { abyssalsire -> 
	set_combat_def(abyssalsire) {

		configs {
			attackSpeed = 7
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 400
			attack = 180
			strength = 136
			defence = 250
			magic = 200
			ranged = 1
		 }

		bonuses {
			attackBonus = 65
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 40
			defenceSlash = 60
			defenceCrush = 50
			defenceMagic = 20
			defenceRanged = 60
		 }

		anims {
			attack = 1
			block = 1
			death = 7100
		 }

		slayerData {
			levelRequirement = 85
			xp = 450.00
		 }
	 }
}
