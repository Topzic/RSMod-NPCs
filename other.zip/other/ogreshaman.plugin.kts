package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.OGRE_SHAMAN, Npcs.OGRE_SHAMAN_2418, Npcs.OGRE_SHAMAN_4382, Npcs.OGRE_SHAMAN_4383, Npcs.OGRE_SHAMAN_4384, Npcs.OGRE_SHAMAN_4386, Npcs.OGRE_SHAMAN_4387, Npcs.OGRE_SHAMAN_4388, Npcs.OGRE_SHAMAN_4389, Npcs.OGRE_SHAMAN_4390, Npcs.OGRE_SHAMAN_4391, Npcs.OGRE_SHAMAN_4392, Npcs.OGRE_SHAMAN_4393, Npcs.OGRE_SHAMAN_4394, Npcs.OGRE_SHAMAN_4395, Npcs.OGRE_SHAMAN_4396, Npcs.OGRE_SHAMAN_4571, Npcs.OGRESS_SHAMAN, Npcs.OGRESS_SHAMAN_7992).forEach { ogreshaman ->
	set_combat_def(ogreshaman) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 1
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 359
			block = 360
			death = 361
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
