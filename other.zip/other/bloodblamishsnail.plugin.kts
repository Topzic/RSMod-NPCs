package gg.rsmod.plugins.content.npcs.npcInfo.bloodblamishsnail

arrayOf(Npcs.BLOOD_BLAMISH_SNAIL, Npcs.BLOOD_BLAMISH_SNAIL_2650).forEach { bloodblamishsnail -> 
	set_combat_def(bloodblamishsnail) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 13
			attack = 0
			strength = 0
			defence = 45
			magic = 1
			ranged = 12
		 }

		bonuses {
			attackBonus = 10
			strengthBonus = 10
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 5
			defenceSlash = 5
			defenceCrush = 30
			defenceMagic = 5
			defenceRanged = 50
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
