package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GELATINNOTH_MOTHER, Npcs.GELATINNOTH_MOTHER_4885, Npcs.GELATINNOTH_MOTHER_4886, Npcs.GELATINNOTH_MOTHER_4887, Npcs.GELATINNOTH_MOTHER_4888, Npcs.GELATINNOTH_MOTHER_4889, Npcs.GELATINNOTH_MOTHER_HARD, Npcs.GELATINNOTH_MOTHER_HARD_6313, Npcs.GELATINNOTH_MOTHER_HARD_6314, Npcs.GELATINNOTH_MOTHER_HARD_6315, Npcs.GELATINNOTH_MOTHER_HARD_6316, Npcs.GELATINNOTH_MOTHER_HARD_6317, Npcs.GELATINNOTH_MOTHER_6373, Npcs.GELATINNOTH_MOTHER_6374, Npcs.GELATINNOTH_MOTHER_6375, Npcs.GELATINNOTH_MOTHER_6376, Npcs.GELATINNOTH_MOTHER_6377, Npcs.GELATINNOTH_MOTHER_6378).forEach { gelatinnothmother -> 
	set_combat_def(gelatinnothmother) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 240
			attack = 78
			strength = 78
			defence = 81
			magic = 1
			ranged = 50
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 150
			defenceSlash = 150
			defenceCrush = 150
			defenceMagic = 50
			defenceRanged = 50
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
