package gg.rsmod.plugins.content.npcs.npcInfo.giantmole

arrayOf(Npcs.GIANT_MOLE, Npcs.GIANT_MOLE_6499).forEach { giantmole -> 
	set_combat_def(giantmole) {

		configs {
			attackSpeed = 4
			respawnDelay = 9
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 200
			attack = 200
			strength = 200
			defence = 200
			magic = 200
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 60
			defenceSlash = 80
			defenceCrush = 100
			defenceMagic = 80
			defenceRanged = 60
		 }

		anims {
			attack = 3312
			block = 3311
			death = 3310
		 }

		slayerData {
			levelRequirement = 0
			xp = 215.00
		 }
	 }
}