package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.NECHRYAEL_8, Npcs.NECHRYAEL_11).forEach { nechryael ->
	set_combat_def(nechryael) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 105
			attack = 97
			strength = 97
			defence = 105
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 20
			defenceMagic = 0
			defenceRanged = 20
		 }

		anims {
			attack = 1528
			block = 1531
			death = 1530
		 }

		slayerData {
			levelRequirement = 80
			xp = 105.00
		 }
	 }
}
