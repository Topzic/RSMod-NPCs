package gg.rsmod.plugins.content.npcs.npcInfo.animatedblackarmour

arrayOf(Npcs.ANIMATED_BLACK_ARMOUR).forEach { animatedblackarmour -> 
	set_combat_def(animatedblackarmour) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 60
			attack = 60
			strength = 60
			defence = 60
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 4
			magicDamageBonus = 0
			attackRanged = 4
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 25
			defenceCrush = 19
			defenceMagic = 400
			defenceRanged = 400
		 }

		anims {
			attack = 386
			block = 388
			death = 4167
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
