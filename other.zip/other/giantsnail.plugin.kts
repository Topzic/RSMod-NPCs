package gg.rsmod.plugins.content.npcs.npcInfo.giantsnail

arrayOf(Npcs.GIANT_SNAIL, Npcs.GIANT_SNAIL_5629, Npcs.GIANT_SNAIL_5630).forEach { giantsnail -> 
	set_combat_def(giantsnail) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 125
			attack = 30
			strength = 30
			defence = 60
			magic = 30
			ranged = 70
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
