package gg.rsmod.plugins.content.npcs.npcInfo.nazastarool

arrayOf(Npcs.NAZASTAROOL, Npcs.NAZASTAROOL_5354, Npcs.NAZASTAROOL_5355, Npcs.NAZASTAROOL_HARD, Npcs.NAZASTAROOL_HARD_6338, Npcs.NAZASTAROOL_HARD_6339, Npcs.NAZASTAROOL_6398, Npcs.NAZASTAROOL_6399, Npcs.NAZASTAROOL_6400).forEach { nazastarool -> 
	set_combat_def(nazastarool) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 70
			attack = 85
			strength = 80
			defence = 80
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 16.00
		 }
	 }
}
