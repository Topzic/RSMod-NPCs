package gg.rsmod.plugins.content.npcs.npcInfo.reanimatedchaosdruid

arrayOf(Npcs.REANIMATED_CHAOS_DRUID).forEach { reanimatedchaosdruid -> 
	set_combat_def(reanimatedchaosdruid) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 35
			attack = 8
			strength = 8
			defence = 12
			magic = 10
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 15
			defenceSlash = 15
			defenceCrush = 15
			defenceMagic = 15
			defenceRanged = 15
		 }

		anims {
			attack = 422
			block = 425
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 584.00
		 }
	 }
}
