package gg.rsmod.plugins.content.npcs.npcInfo.knightofsaradomin

arrayOf(Npcs.KNIGHT_OF_SARADOMIN, Npcs.KNIGHT_OF_SARADOMIN_2214).forEach { knightofsaradomin -> 
	set_combat_def(knightofsaradomin) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 108
			attack = 75
			strength = 90
			defence = 82
			magic = 60
			ranged = 1
		 }

		bonuses {
			attackBonus = 13
			strengthBonus = 11
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 12
			defenceSlash = 14
			defenceCrush = 13
			defenceMagic = 0
			defenceRanged = 13
		 }

		anims {
			attack = 406
			block = 410
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
