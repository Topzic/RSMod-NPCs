package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.NIGHT_BEAST).forEach { nightbeast -> 
	set_combat_def(nightbeast) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 550
			attack = 270
			strength = 290
			defence = 220
			magic = 300
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 75
			defenceSlash = 80
			defenceCrush = 200
			defenceMagic = 190
			defenceRanged = 200
		 }

		anims {
			attack = 2731
			block = 2732
			death = 2733
		 }

		slayerData {
			levelRequirement = 90
			xp = 6462.00
		 }
	 }
}
