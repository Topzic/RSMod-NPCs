package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DEATHLY_MAGE).forEach { deathlymage -> 
	set_combat_def(deathlymage) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 120
			attack = 1
			strength = 1
			defence = 155
			magic = 210
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 120
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1162
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 0.00
		 }
	 }
}
