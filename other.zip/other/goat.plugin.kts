package gg.rsmod.plugins.content.npcs.npcInfo.goat

arrayOf(Npcs.MOUNTAIN_GOAT, Npcs.MOUNTAIN_GOAT_1385, Npcs.MOUNTAIN_GOAT_1386, Npcs.MOUNTAIN_GOAT_1387, Npcs.GOAT, Npcs.GOAT_1793, Npcs.GOAT_1795, Npcs.GOAT_1796, Npcs.MOUNTAIN_GOAT_4117, Npcs.MOUNTAIN_GOAT_4145, Npcs.MOUNTAIN_GOAT_4146, Npcs.MOUNTAIN_GOAT_4147).forEach { goat ->
	set_combat_def(goat) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 21
			attack = 20
			strength = 20
			defence = 20
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 10
			strengthBonus = 29
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 10
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
