package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.POISON_SPIDER, Npcs.POISON_SPIDER_5373).forEach { poisonspider -> 
	set_combat_def(poisonspider) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 25
			attack = 28
			strength = 28
			defence = 28
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 17
			defenceCrush = 10
			defenceMagic = 14
			defenceRanged = 14
		 }

		anims {
			attack = 5327
			block = 5328
			death = 5329
		 }

		slayerData {
			levelRequirement = 0
			xp = 10.00
		 }
	 }
}
