package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GRAVE_SCORPION).forEach { gravescorpion -> 
	set_combat_def(gravescorpion) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 7
			attack = 11
			strength = 12
			defence = 14
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 3
			defenceCrush = 3
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 7.00
		 }
	 }
}
