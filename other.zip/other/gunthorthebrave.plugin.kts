package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GUNTHOR_THE_BRAVE).forEach { gunthorthebrave -> 
	set_combat_def(gunthorthebrave) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 35
			attack = 22
			strength = 22
			defence = 25
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 8
			magicDamageBonus = 0
			attackRanged = 8
			rangedStrengthBonus = 0
			defenceStab = 12
			defenceSlash = 14
			defenceCrush = 10
			defenceMagic = 1
			defenceRanged = 11
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
