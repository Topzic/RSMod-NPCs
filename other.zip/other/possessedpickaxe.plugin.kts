package gg.rsmod.plugins.content.npcs.npcInfo.possessedpickaxe

arrayOf(Npcs.POSSESSED_PICKAXE, Npcs.POSSESSED_PICKAXE_6469, Npcs.POSSESSED_PICKAXE_7268).forEach { possessedpickaxe -> 
	set_combat_def(possessedpickaxe) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 40
			attack = 40
			strength = 55
			defence = 40
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 15
			defenceSlash = 10
			defenceCrush = 5
			defenceMagic = 5
			defenceRanged = 10
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
