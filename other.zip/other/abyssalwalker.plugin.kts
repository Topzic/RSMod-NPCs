package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ABYSSAL_WALKER, Npcs.ABYSSAL_WALKER_11406, Npcs.ABYSSAL_WALKER_11454).forEach { abyssalwalker -> 
	set_combat_def(abyssalwalker) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 95
			attack = 5
			strength = 100
			defence = 95
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 5
			magicDamageBonus = 0
			attackRanged = 5
			rangedStrengthBonus = 0
			defenceStab = 75
			defenceSlash = 75
			defenceCrush = 10
			defenceMagic = 75
			defenceRanged = 75
		 }

		anims {
			attack = 2192
			block = 2193
			death = 2194
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
