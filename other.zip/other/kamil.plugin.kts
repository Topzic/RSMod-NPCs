package gg.rsmod.plugins.content.npcs.npcInfo.kamil

arrayOf(Npcs.KAMIL_HARD, Npcs.KAMIL, Npcs.KAMIL_6345).forEach { kamil -> 
	set_combat_def(kamil) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 130
			attack = 190
			strength = 80
			defence = 135
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 60
			strengthBonus = 100
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 35
			defenceSlash = 60
			defenceCrush = 35
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 146.00
		 }
	 }
}
