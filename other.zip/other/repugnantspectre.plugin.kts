package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.REPUGNANT_SPECTRE).forEach { repugnantspectre -> 
	set_combat_def(repugnantspectre) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 390
			attack = 1
			strength = 1
			defence = 220
			magic = 380
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 120
			defenceSlash = 120
			defenceCrush = 120
			defenceMagic = 0
			defenceRanged = 115
		 }

		anims {
			attack = 6368
			block = 6370
			death = 6369
		 }

		slayerData {
			levelRequirement = 60
			xp = 78.00
		 }
	 }
}
