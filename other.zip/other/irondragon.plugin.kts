package gg.rsmod.plugins.content.npcs.npcInfo.irondragon

arrayOf(Npcs.IRON_DRAGON, Npcs.IRON_DRAGON_273, Npcs.IRON_DRAGON_7254, Npcs.IRON_DRAGON_8080).forEach { irondragon -> 
	set_combat_def(irondragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 165
			attack = 165
			strength = 165
			defence = 165
			magic = 100
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 30
			defenceRanged = 90
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 0
			xp = 173.20
		 }
	 }
}
