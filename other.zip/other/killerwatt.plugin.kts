package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.KILLERWATT_469, Npcs.KILLERWATT_470).forEach { killerwatt -> 
	set_combat_def(killerwatt) {

		configs {
			attackSpeed = 2
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 51
			attack = 50
			strength = 50
			defence = 40
			magic = 67
			ranged = 67
		 }

		bonuses {
			attackBonus = 30
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 10
			defenceMagic = 20
			defenceRanged = 20
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 37
			xp = 51.00
		 }
	 }
}
