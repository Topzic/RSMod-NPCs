package gg.rsmod.plugins.content.npcs.npcInfo.blackguard

arrayOf(Npcs.BLACK_GUARD, Npcs.BLACK_GUARD_1410, Npcs.BLACK_GUARD_1411, Npcs.BLACK_GUARD_1412, Npcs.BLACK_GUARD_6046, Npcs.BLACK_GUARD_6047, Npcs.BLACK_GUARD_6048, Npcs.BLACK_GUARD_6049, Npcs.BLACK_GUARD_8474, Npcs.BLACK_GUARD_8475, Npcs.BLACK_GUARD_8476).forEach { blackguard ->
	set_combat_def(blackguard) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 30
			attack = 20
			strength = 20
			defence = 20
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 5
			strengthBonus = 7
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 3
			defenceSlash = 4
			defenceCrush = 4
			defenceMagic = 2
			defenceRanged = 3
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 30.00
		 }
	 }
}
