package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GHOST, Npcs.GHOST_86, Npcs.GHOST_87, Npcs.GHOST_88, Npcs.GHOST_89, Npcs.GHOST_90, Npcs.GHOST_91, Npcs.GHOST_92, Npcs.GHOST_93, Npcs.GHOST_94, Npcs.GHOST_95, Npcs.GHOST_96, Npcs.GHOST_97, Npcs.GHOST_98, Npcs.GHOST_99, Npcs.GHOST_472, Npcs.GHOST_473, Npcs.GHOST_474, Npcs.GHOST_505, Npcs.GHOST_506, Npcs.GHOST_507, Npcs.GHOST_920, Npcs.GHOST_1786, Npcs.GHOST_2527, Npcs.GHOST_2528, Npcs.GHOST_2529, Npcs.GHOST_2530, Npcs.GHOST_2531, Npcs.GHOST_2532, Npcs.GHOST_2533, Npcs.GHOST_2534, Npcs.GHOST_, Npcs.GHOST__3009, Npcs.GHOST_3516, Npcs.GHOST_3617, Npcs.GHOST_3625, Npcs.GHOST_3975, Npcs.GHOST_3976, Npcs.GHOST_3977, Npcs.GHOST_3978, Npcs.GHOST_3979, Npcs.GHOST_5370, Npcs.GHOST_7263, Npcs.GHOST_7264, Npcs.GHOST_9194, Npcs.GHOST_10538, Npcs.GHOST_10697, Npcs.GHOST_10698, Npcs.GHOST_10699, Npcs.GHOST_11301).forEach { ghost ->
	set_combat_def(ghost) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 25
			attack = 13
			strength = 13
			defence = 18
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 5
			defenceSlash = 5
			defenceCrush = 5
			defenceMagic = 5
			defenceRanged = 5
		 }

		anims {
			attack = 5532
			block = 5533
			death = 5534
		 }

		slayerData {
			levelRequirement = 0
			xp = 5.00
		 }
	 }
}
