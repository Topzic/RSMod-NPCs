package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BANDIT_690, Npcs.BANDIT_691, Npcs.BANDIT_692, Npcs.BANDIT_693, Npcs.BANDIT_694, Npcs.BANDIT_695, Npcs.BANDIT_LEADER, Npcs.BANDIT_734, Npcs.BANDIT_735, Npcs.BANDIT_736, Npcs.BANDIT_737, Npcs.COWARDLY_BANDIT, Npcs.BANDIT_1026, Npcs.BANDIT_6605, Npcs.BANDIT_11063, Npcs.BANDIT_11064, Npcs.BANDIT_11065).forEach { bandit ->
	set_combat_def(bandit) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 27
			attack = 17
			strength = 17
			defence = 17
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 11
			strengthBonus = 12
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 3
			defenceCrush = 2
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 417
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 29.00
		 }
	 }
}
