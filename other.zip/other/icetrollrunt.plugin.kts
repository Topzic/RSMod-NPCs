package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ICE_TROLL_RUNT, Npcs.ICE_TROLL_RUNT_5823, Npcs.ICE_TROLL_RUNT_5828).forEach { icetrollrunt -> 
	set_combat_def(icetrollrunt) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 60
			attack = 60
			strength = 70
			defence = 70
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 60
			strengthBonus = 60
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 60
			defenceCrush = 30
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 63.00
		 }
	 }
}
