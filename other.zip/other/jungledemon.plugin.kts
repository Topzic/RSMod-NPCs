package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.JUNGLE_DEMON, Npcs.JUNGLE_DEMON_HARD, Npcs.JUNGLE_DEMON_6382).forEach { jungledemon -> 
	set_combat_def(jungledemon) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 170
			attack = 170
			strength = 170
			defence = 170
			magic = 170
			ranged = 1
		 }

		bonuses {
			attackBonus = 50
			strengthBonus = 50
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 50
			defenceCrush = 0
			defenceMagic = 50
			defenceRanged = 0
		 }

		anims {
			attack = 64
			block = 65
			death = 67
		 }

		slayerData {
			levelRequirement = 1
			xp = 250.00
		 }
	 }
}
