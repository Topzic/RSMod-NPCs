package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.FIRE_GIANT, Npcs.FIRE_GIANT_2076, Npcs.FIRE_GIANT_2077, Npcs.FIRE_GIANT_2078, Npcs.FIRE_GIANT_2079, Npcs.FIRE_GIANT_2080, Npcs.FIRE_GIANT_2081, Npcs.FIRE_GIANT_2082, Npcs.FIRE_GIANT_2083, Npcs.FIRE_GIANT_2084, Npcs.FIRE_GIANT_7251, Npcs.FIRE_GIANT_7252).forEach { firegiant -> 
	set_combat_def(firegiant) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
		 }

		stats {
			hitpoints = 111
			attack = 65
			strength = 65
			defence = 65
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 29
			strengthBonus = 31
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 3
			defenceCrush = 2
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 4666
			block = 4665
			death = 4668
		 }

		slayerData {
			levelRequirement = 0
			xp = 111.00
		 }
	 }
}
