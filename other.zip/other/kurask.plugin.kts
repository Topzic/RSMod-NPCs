package gg.rsmod.plugins.content.npcs.npcInfo.kurask

arrayOf(Npcs.KURASK_123, Npcs.KURASK_410, Npcs.KURASK_411).forEach { kurask ->
	set_combat_def(kurask) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 97
			attack = 67
			strength = 105
			defence = 105
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 20
			defenceCrush = 20
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1512
			block = 1514
			death = 1513
		 }

		slayerData {
			levelRequirement = 70
			xp = 97.00
		 }
	 }
}
