package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.KEEF, Npcs.KEEF_7105).forEach { keef -> 
	set_combat_def(keef) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 180
			attack = 165
			strength = 120
			defence = 165
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 190
			magicDamageBonus = 0
			attackRanged = 190
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 50
			defenceCrush = 50
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
