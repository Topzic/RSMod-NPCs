package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DESERT_LIZARD_459, Npcs.DESERT_LIZARD_460, Npcs.DESERT_LIZARD_461).forEach { desertlizard -> 
	set_combat_def(desertlizard) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 25
			attack = 20
			strength = 22
			defence = 20
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 5
			defenceSlash = 15
			defenceCrush = 15
			defenceMagic = 0
			defenceRanged = 5
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 22
			xp = 25.00
		 }
	 }
}
