package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.RIVER_TROLL, Npcs.RIVER_TROLL_6733, Npcs.RIVER_TROLL_6734, Npcs.RIVER_TROLL_6735, Npcs.RIVER_TROLL_6736, Npcs.RIVER_TROLL_6737).forEach { rivertroll -> 
	set_combat_def(rivertroll) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 25
			attack = 9
			strength = 9
			defence = 9
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 1.00
		 }
	 }
}
