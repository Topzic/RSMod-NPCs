package gg.rsmod.plugins.content.npcs.npcInfo.icedemon

arrayOf(Npcs.ICE_DEMON, Npcs.ICE_DEMON_7585).forEach { icedemon -> 
	set_combat_def(icedemon) {

		configs {
			attackSpeed = 3
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 140
			attack = 1
			strength = 1
			defence = 160
			magic = 390
			ranged = 390
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 70
			defenceSlash = 70
			defenceCrush = 110
			defenceMagic = 60
			defenceRanged = 140
		 }

		anims {
			attack = 69
			block = 65
			death = 67
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
