package gg.rsmod.plugins.content.npcs.npcInfo.chasmcrawler

arrayOf(Npcs.CHASM_CRAWLER).forEach { chasmcrawler -> 
	set_combat_def(chasmcrawler) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 1
			attack = 22
			strength = 18
			defence = 18
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 5
			defenceMagic = 5
			defenceRanged = 10
		 }

		anims {
			attack = 227
			block = 1504
			death = 228
		 }

		slayerData {
			levelRequirement = 10
			xp = 600.00
		 }
	 }
}
