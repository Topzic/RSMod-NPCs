package gg.rsmod.plugins.content.npcs.npcInfo.pestilentbloat

arrayOf(Npcs.PESTILENT_BLOAT, Npcs.PESTILENT_BLOAT_10812, Npcs.PESTILENT_BLOAT_10813, Npcs.PESTILENT_BLOAT_11184).forEach { pestilentbloat -> 
	set_combat_def(pestilentbloat) {

		configs {
			attackSpeed = 1
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 1600
			attack = 100
			strength = 180
			defence = 80
			magic = 120
			ranged = 72
		 }

		bonuses {
			attackBonus = 60
			strengthBonus = 46
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 72
			rangedStrengthBonus = 2
			defenceStab = 10
			defenceSlash = 5
			defenceCrush = 10
			defenceMagic = 600
			defenceRanged = 800
		 }

		anims {
			attack = 1
			block = 1
			death = 8094
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
