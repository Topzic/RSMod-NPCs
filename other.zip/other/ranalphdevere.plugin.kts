package gg.rsmod.plugins.content.npcs.npcInfo.ranalphdevere

arrayOf(Npcs.RANALPH_DEVERE).forEach { ranalphdevere -> 
	set_combat_def(ranalphdevere) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 130
			attack = 66
			strength = 67
			defence = 66
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 45
			magicDamageBonus = 0
			attackRanged = 45
			rangedStrengthBonus = 0
			defenceStab = 38
			defenceSlash = 40
			defenceCrush = 36
			defenceMagic = 0
			defenceRanged = 38
		 }

		anims {
			attack = 5485
			block = 5489
			death = 5491
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
