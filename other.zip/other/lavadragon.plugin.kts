package gg.rsmod.plugins.content.npcs.npcInfo.lavadragon

arrayOf(Npcs.LAVA_DRAGON).forEach { lavadragon -> 
	set_combat_def(lavadragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 230
			attack = 240
			strength = 220
			defence = 220
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 70
			defenceSlash = 90
			defenceCrush = 90
			defenceMagic = 80
			defenceRanged = 70
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 1
			xp = 248.00
		 }
	 }
}
