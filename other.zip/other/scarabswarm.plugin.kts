package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.SCARAB_SWARM, Npcs.SCARAB_SWARM_4192, Npcs.SCARAB_SWARM_11484, Npcs.SCARAB_SWARM_11509, Npcs.SCARAB_SWARM_11569).forEach { scarabswarm -> 
	set_combat_def(scarabswarm) {

		configs {
			attackSpeed = 1
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 25
			attack = 255
			strength = 5
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 90
			defenceSlash = 90
			defenceCrush = 5
			defenceMagic = 90
			defenceRanged = 90
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 1.00
		 }
	 }
}
