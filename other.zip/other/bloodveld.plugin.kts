package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BLOODVELD_484, Npcs.BLOODVELD_485, Npcs.BLOODVELD_486, Npcs.BLOODVELD_487, Npcs.BLOODVELD_3138).forEach { bloodveld ->
	set_combat_def(bloodveld) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 120
			attack = 75
			strength = 45
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1552
			block = 1550
			death = 1553
		 }

		slayerData {
			levelRequirement = 50
			xp = 120.00
		 }
	 }
}
