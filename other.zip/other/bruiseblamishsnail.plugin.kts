package gg.rsmod.plugins.content.npcs.npcInfo.bruiseblamishsnail

arrayOf(Npcs.BRUISE_BLAMISH_SNAIL, Npcs.BRUISE_BLAMISH_SNAIL_2652).forEach { bruiseblamishsnail -> 
	set_combat_def(bruiseblamishsnail) {

		configs {
			attackSpeed = 6
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 12
			attack = 0
			strength = 0
			defence = 40
			magic = 1
			ranged = 15
		 }

		bonuses {
			attackBonus = 10
			strengthBonus = 10
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 5
			defenceSlash = 5
			defenceCrush = 30
			defenceMagic = 5
			defenceRanged = 50
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
