package gg.rsmod.plugins.content.npcs.npcInfo.commanderzilyana

arrayOf(Npcs.COMMANDER_ZILYANA, Npcs.COMMANDER_ZILYANA_6493).forEach { commanderzilyana -> 
	set_combat_def(commanderzilyana) {

		configs {
			attackSpeed = 2
			respawnDelay = 18
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 255
			attack = 280
			strength = 196
			defence = 300
			magic = 300
			ranged = 250
		 }

		bonuses {
			attackBonus = 195
			strengthBonus = 20
			attackMagic = 200
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 100
			defenceSlash = 100
			defenceCrush = 100
			defenceMagic = 100
			defenceRanged = 100
		 }

		anims {
			attack = 6967
			block = 6969
			death = 6968
		 }

		slayerData {
			levelRequirement = 0
			xp = 350.00
		 }
	 }
}
