package gg.rsmod.plugins.content.npcs.npcInfo.molanisk

arrayOf(Npcs.MOLANISK_1).forEach { molanisk -> 
	set_combat_def(molanisk) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 52
			attack = 40
			strength = 40
			defence = 50
			magic = 0
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 45
			defenceSlash = 45
			defenceCrush = 35
			defenceMagic = 30
			defenceRanged = 55
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 39
			xp = 52.00
		 }
	 }
}
