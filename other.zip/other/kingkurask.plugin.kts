package gg.rsmod.plugins.content.npcs.npcInfo.kingkurask

arrayOf(Npcs.KING_KURASK).forEach { kingkurask -> 
	set_combat_def(kingkurask) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 420
			attack = 190
			strength = 320
			defence = 250
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 50
			defenceCrush = 50
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 4235
			block = 4232
			death = 4233
		 }

		slayerData {
			levelRequirement = 70
			xp = 276.70
		 }
	 }
}
