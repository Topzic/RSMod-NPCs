package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ABYSSAL_LEECH, Npcs.ABYSSAL_LEECH_11407).forEach { abyssalleech -> 
	set_combat_def(abyssalleech) {

		configs {
			attackSpeed = 2
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
		 }

		stats {
			hitpoints = 10
			attack = 95
			strength = 5
			defence = 25
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 100
			magicDamageBonus = 0
			attackRanged = 100
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 50
			defenceCrush = 100
			defenceMagic = 50
			defenceRanged = 10
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
