package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GRIZZLY_BEAR, Npcs.GRIZZLY_BEAR_3423).forEach { grizzlybear ->
	set_combat_def(grizzlybear) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 27
			attack = 17
			strength = 18
			defence = 15
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 4925
			block = 4927
			death = 4929
		 }

		slayerData {
			levelRequirement = 0
			xp = 27.00
		 }
	 }
}
