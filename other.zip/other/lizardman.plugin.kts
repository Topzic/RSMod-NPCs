package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.LIZARDMAN, Npcs.LIZARDMAN_6915, Npcs.LIZARDMAN_6916, Npcs.LIZARDMAN_6917, Npcs.LIZARDMAN_8563, Npcs.LIZARDMAN_10948).forEach { lizardman ->
	set_combat_def(lizardman) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 60
			attack = 43
			strength = 43
			defence = 43
			magic = 1
			ranged = 43
		 }

		bonuses {
			attackBonus = 22
			strengthBonus = 20
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 22
			rangedStrengthBonus = 20
			defenceStab = 10
			defenceSlash = 25
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 7192
			block = 7194
			death = 7196
		 }

		slayerData {
			levelRequirement = 0
			xp = 60.00
		 }
	 }
}
