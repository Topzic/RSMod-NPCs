package gg.rsmod.plugins.content.npcs.npcInfo.reanimatedogre

arrayOf(Npcs.REANIMATED_OGRE).forEach { reanimatedogre -> 
	set_combat_def(reanimatedogre) {

		configs {
			attackSpeed = 6
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 35
			attack = 18
			strength = 22
			defence = 26
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 18
			defenceSlash = 18
			defenceCrush = 18
			defenceMagic = 18
			defenceRanged = 18
		 }

		anims {
			attack = 359
			block = 360
			death = 361
		 }

		slayerData {
			levelRequirement = 1
			xp = 716.00
		 }
	 }
}
