package gg.rsmod.plugins.content.npcs.npcInfo.insatiablebloodveld

arrayOf(Npcs.INSATIABLE_BLOODVELD).forEach { insatiablebloodveld -> 
	set_combat_def(insatiablebloodveld) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 380
			attack = 190
			strength = 145
			defence = 85
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1552
			block = 1550
			death = 1553
		 }

		slayerData {
			levelRequirement = 50
			xp = 290.00
		 }
	 }
}
