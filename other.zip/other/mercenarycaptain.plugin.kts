package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MERCENARY_CAPTAIN).forEach { mercenarycaptain -> 
	set_combat_def(mercenarycaptain) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 80
			attack = 32
			strength = 29
			defence = 32
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 9
			magicDamageBonus = 0
			attackRanged = 9
			rangedStrengthBonus = 0
			defenceStab = 17
			defenceSlash = 15
			defenceCrush = 19
			defenceMagic = 3
			defenceRanged = 19
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
