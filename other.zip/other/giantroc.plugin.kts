package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GIANT_ROC, Npcs.GIANT_ROC_HARD, Npcs.GIANT_ROC_6384).forEach { giantroc ->
	set_combat_def(giantroc) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 250
			attack = 130
			strength = 130
			defence = 100
			magic = 1
			ranged = 130
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 150
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 250.00
		 }
	 }
}
