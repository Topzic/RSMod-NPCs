package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.POISON_SCORPION).forEach { poisonscorpion -> 
	set_combat_def(poisonscorpion) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 23
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 6254
			block = 6255
			death = 6256
		 }

		slayerData {
			levelRequirement = 1
			xp = 23.00
		 }
	 }
}
