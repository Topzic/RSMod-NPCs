package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GEORGY).forEach { georgy -> 
	set_combat_def(georgy) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 60
			attack = 10
			strength = 10
			defence = 10
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 21
			defenceSlash = 21
			defenceCrush = 21
			defenceMagic = 21
			defenceRanged = 21
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
