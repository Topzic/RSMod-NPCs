package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.JAIL_GUARD, Npcs.JAIL_GUARD_4277, Npcs.JAIL_GUARD_4278, Npcs.JAIL_GUARD_4279).forEach { jailguard -> 
	set_combat_def(jailguard) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 32
			attack = 19
			strength = 23
			defence = 21
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 9
			strengthBonus = 5
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 8
			defenceSlash = 9
			defenceCrush = 10
			defenceMagic = 4
			defenceRanged = 9
		 }

		anims {
			attack = 401
			block = 403
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
