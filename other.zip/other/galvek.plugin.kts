package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GALVEK, Npcs.GALVEK_8095, Npcs.GALVEK_8096, Npcs.GALVEK_8097, Npcs.GALVEK_8098, Npcs.GALVEK_8177, Npcs.GALVEK_8178, Npcs.GALVEK_8179).forEach { galvek -> 
	set_combat_def(galvek) {

		configs {
			attackSpeed = 6
			respawnDelay = 21
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 1200
			attack = 632
			strength = 268
			defence = 188
			magic = 160
			ranged = 246
		 }

		bonuses {
			attackBonus = 34
			strengthBonus = 0
			attackMagic = 160
			magicDamageBonus = 42
			attackRanged = 180
			rangedStrengthBonus = 6
			defenceStab = 80
			defenceSlash = 140
			defenceCrush = 140
			defenceMagic = 280
			defenceRanged = 86
		 }

		anims {
			attack = 1
			block = 1
			death = 7915
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
