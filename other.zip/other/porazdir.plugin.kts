package gg.rsmod.plugins.content.npcs.npcInfo.porazdir

arrayOf(Npcs.PORAZDIR, Npcs.PORAZDIR_7860).forEach { porazdir -> 
	set_combat_def(porazdir) {

		configs {
			attackSpeed = 6
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 320
			attack = 250
			strength = 150
			defence = 100
			magic = 180
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 80
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 200
			defenceSlash = 200
			defenceCrush = 200
			defenceMagic = 60
			defenceRanged = 200
		 }

		anims {
			attack = 7840
			block = 7838
			death = 7843
		 }

		slayerData {
			levelRequirement = 1
			xp = 376.00
		 }
	 }
}
