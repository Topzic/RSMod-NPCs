package gg.rsmod.plugins.content.npcs.npcInfo.dagannothmother

arrayOf(Npcs.DAGANNOTH_MOTHER, Npcs.DAGANNOTH_MOTHER_981, Npcs.DAGANNOTH_MOTHER_982, Npcs.DAGANNOTH_MOTHER_983, Npcs.DAGANNOTH_MOTHER_984, Npcs.DAGANNOTH_MOTHER_985, Npcs.DAGANNOTH_MOTHER_986, Npcs.DAGANNOTH_MOTHER_987, Npcs.DAGANNOTH_MOTHER_988, Npcs.DAGANNOTH_MOTHER_HARD, Npcs.DAGANNOTH_MOTHER_HARD_6301, Npcs.DAGANNOTH_MOTHER_HARD_6302, Npcs.DAGANNOTH_MOTHER_HARD_6303, Npcs.DAGANNOTH_MOTHER_HARD_6304, Npcs.DAGANNOTH_MOTHER_HARD_6305, Npcs.DAGANNOTH_MOTHER_6361, Npcs.DAGANNOTH_MOTHER_6362, Npcs.DAGANNOTH_MOTHER_6363, Npcs.DAGANNOTH_MOTHER_6364, Npcs.DAGANNOTH_MOTHER_6365, Npcs.DAGANNOTH_MOTHER_6366).forEach { dagannothmother -> 
	set_combat_def(dagannothmother) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 120
			attack = 78
			strength = 78
			defence = 81
			magic = 1
			ranged = 50
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 150
			defenceSlash = 150
			defenceCrush = 150
			defenceMagic = 50
			defenceRanged = 50
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
