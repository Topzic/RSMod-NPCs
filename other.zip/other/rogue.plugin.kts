package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ROGUE_526, Npcs.ROGUE_GUARD, Npcs.ROGUE_GUARD_3191, Npcs.ROGUE_GUARD_3192, Npcs.ROGUE_6603).forEach { rogue -> 
	set_combat_def(rogue) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 17
			attack = 13
			strength = 13
			defence = 13
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 5
			strengthBonus = 5
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 6
			defenceSlash = 9
			defenceCrush = 11
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 0
			xp = 365.00
		 }
	 }
}
