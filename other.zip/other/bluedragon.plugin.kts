package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BLUE_DRAGON, Npcs.BLUE_DRAGON_266, Npcs.BLUE_DRAGON_267, Npcs.BLUE_DRAGON_268, Npcs.BLUE_DRAGON_269, Npcs.BLUE_DRAGON_4385, Npcs.BLUE_DRAGON_5878, Npcs.BLUE_DRAGON_5879, Npcs.BLUE_DRAGON_5880, Npcs.BLUE_DRAGON_5881, Npcs.BLUE_DRAGON_5882, Npcs.BLUE_DRAGON_8074, Npcs.BLUE_DRAGON_8077, Npcs.BLUE_DRAGON_8083).forEach { bluedragon ->
	set_combat_def(bluedragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 105
			attack = 95
			strength = 95
			defence = 95
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 60
			defenceRanged = 50
		 }

		anims {
			attack = 91
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 0
			xp = 107.60
		 }
	 }
}
