package gg.rsmod.plugins.content.npcs.npcInfo.fearreaper

arrayOf(Npcs.FEAR_REAPER, Npcs.FEAR_REAPER_4693).forEach { fearreaper -> 
	set_combat_def(fearreaper) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 25
			attack = 39
			strength = 41
			defence = 40
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
