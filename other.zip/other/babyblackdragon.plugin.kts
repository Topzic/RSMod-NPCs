package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BABY_BLACK_DRAGON, Npcs.BABY_BLACK_DRAGON_1872, Npcs.BABY_BLACK_DRAGON_7955).forEach { babyblackdragon -> 
	set_combat_def(babyblackdragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 80
			attack = 70
			strength = 70
			defence = 70
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 50
			defenceCrush = 50
			defenceMagic = 40
			defenceRanged = 30
		 }

		anims {
			attack = 25
			block = 26
			death = 28
		 }

		slayerData {
			levelRequirement = 1
			xp = 80.00
		 }
	 }
}
