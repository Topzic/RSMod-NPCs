package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.REANIMATED_TZHAAR).forEach { reanimatedtzhaar -> 
	set_combat_def(reanimatedtzhaar) {

		configs {
			attackSpeed = 5
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 35
			attack = 97
			strength = 67
			defence = 67
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 120
			defenceSlash = 140
			defenceCrush = 120
			defenceMagic = 0
			defenceRanged = 40
		 }

		anims {
			attack = 2610
			block = 1
			death = 2607
		 }

		slayerData {
			levelRequirement = 1
			xp = 110.40
		 }
	 }
}
