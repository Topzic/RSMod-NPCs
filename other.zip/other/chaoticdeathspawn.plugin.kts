package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CHAOTIC_DEATH_SPAWN, Npcs.CHAOTIC_DEATH_SPAWN_6723, Npcs.CHAOTIC_DEATH_SPAWN_7649).forEach { chaoticdeathspawn -> 
	set_combat_def(chaoticdeathspawn) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 50
			attack = 380
			strength = 1
			defence = 70
			magic = 380
			ranged = 380
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
