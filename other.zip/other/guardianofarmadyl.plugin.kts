package gg.rsmod.plugins.content.npcs.npcInfo.guardianofarmadyl

arrayOf(Npcs.GUARDIAN_OF_ARMADYL, Npcs.GUARDIAN_OF_ARMADYL_3446).forEach { guardianofarmadyl -> 
	set_combat_def(guardianofarmadyl) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 50
			attack = 37
			strength = 37
			defence = 37
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 14
			strengthBonus = 16
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 43
			defenceSlash = 55
			defenceCrush = 50
			defenceMagic = 12
			defenceRanged = 51
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
