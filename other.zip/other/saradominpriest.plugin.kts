package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.SARADOMIN_PRIEST).forEach { saradominpriest -> 
	set_combat_def(saradominpriest) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 89
			attack = 120
			strength = 46
			defence = 120
			magic = 125
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 9
			magicDamageBonus = 0
			attackRanged = 9
			rangedStrengthBonus = 0
			defenceStab = 12
			defenceSlash = 14
			defenceCrush = 13
			defenceMagic = 5
			defenceRanged = 13
		 }

		anims {
			attack = 811
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
