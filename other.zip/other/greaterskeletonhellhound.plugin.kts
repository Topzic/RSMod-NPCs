package gg.rsmod.plugins.content.npcs.npcInfo.greaterskeletonhellhound

arrayOf(Npcs.GREATER_SKELETON_HELLHOUND).forEach { greaterskeletonhellhound -> 
	set_combat_def(greaterskeletonhellhound) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 190
			attack = 240
			strength = 310
			defence = 220
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 150
			defenceSlash = 163
			defenceCrush = 20
			defenceMagic = 210
			defenceRanged = 275
		 }

		anims {
			attack = 6559
			block = 6557
			death = 6558
		 }

		slayerData {
			levelRequirement = 1
			xp = 214.50
		 }
	 }
}
