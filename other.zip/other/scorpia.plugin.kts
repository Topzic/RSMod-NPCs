package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.SCORPIAS_OFFSPRING_5547, Npcs.SCORPIAS_OFFSPRING_5561, Npcs.SCORPIA, Npcs.SCORPIAS_OFFSPRING_6616, Npcs.SCORPIAS_GUARDIAN).forEach { scorpia -> 
	set_combat_def(scorpia) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 200
			attack = 250
			strength = 150
			defence = 180
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 60
			magicDamageBonus = 0
			attackRanged = 60
			rangedStrengthBonus = 0
			defenceStab = 246
			defenceSlash = 284
			defenceCrush = 284
			defenceMagic = 44
			defenceRanged = 284
		 }

		anims {
			attack = 6254
			block = 6255
			death = 6256
		 }

		slayerData {
			levelRequirement = 1
			xp = 260.00
		 }
	 }
}
