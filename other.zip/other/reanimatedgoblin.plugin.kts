package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.REANIMATED_GOBLIN).forEach { reanimatedgoblin -> 
	set_combat_def(reanimatedgoblin) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 5
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 15
			defenceSlash = 15
			defenceCrush = 15
			defenceMagic = 15
			defenceRanged = 15
		 }

		anims {
			attack = 309
			block = 312
			death = 313
		 }

		slayerData {
			levelRequirement = 1
			xp = 130.00
		 }
	 }
}
