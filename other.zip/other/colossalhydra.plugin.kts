package gg.rsmod.plugins.content.npcs.npcInfo.colossalhydra

arrayOf(Npcs.COLOSSAL_HYDRA).forEach { colossalhydra -> 
	set_combat_def(colossalhydra) {

		configs {
			attackSpeed = 6
			respawnDelay = 18
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 750
			attack = 1
			strength = 1
			defence = 100
			magic = 250
			ranged = 250
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 100
			defenceSlash = 200
			defenceCrush = 200
			defenceMagic = 200
			defenceRanged = 20
		 }

		anims {
			attack = 7008
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 95
			xp = 862.50
		 }
	 }
}
