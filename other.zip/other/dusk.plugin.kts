package gg.rsmod.plugins.content.npcs.npcInfo.dusk

arrayOf(Npcs.DUSK, Npcs.DUSK_7851, Npcs.DUSK_7854, Npcs.DUSK_7855, Npcs.DUSK_7882, Npcs.DUSK_7883, Npcs.DUSK_7886, Npcs.DUSK_7887, Npcs.DUSK_7888, Npcs.DUSK_7889).forEach { dusk -> 
	set_combat_def(dusk) {

		configs {
			attackSpeed = 6
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 450
			attack = 200
			strength = 140
			defence = 100
			magic = 140
			ranged = 140
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 75
			xp = 1350.00
		 }
	 }
}