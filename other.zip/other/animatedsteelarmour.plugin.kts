package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ANIMATED_STEEL_ARMOUR, Npcs.ANIMATED_STEEL_ARMOUR_6438).forEach { animatedsteelarmour -> 
	set_combat_def(animatedsteelarmour) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 50
			attack = 50
			strength = 50
			defence = 2
			magic = 2
			ranged = 2
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 4
			magicDamageBonus = 0
			attackRanged = 4
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 25
			defenceCrush = 25
			defenceMagic = 400
			defenceRanged = 400
		 }

		anims {
			attack = 386
			block = 388
			death = 4167
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
