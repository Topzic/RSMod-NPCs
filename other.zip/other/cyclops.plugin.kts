package gg.rsmod.plugins.content.npcs.npcInfo.cyclops

arrayOf(Npcs.CYCLOPS, Npcs.CYCLOPS_2137, Npcs.CYCLOPS_2138, Npcs.CYCLOPS_2139, Npcs.CYCLOPS_2140, Npcs.CYCLOPS_2141, Npcs.CYCLOPS_2142, Npcs.CYCLOPS_2235, Npcs.CYCLOPS_2236, Npcs.CYCLOPS_2463, Npcs.CYCLOPS_2464, Npcs.CYCLOPS_2465, Npcs.CYCLOPS_2466, Npcs.CYCLOPS_2467, Npcs.CYCLOPS_2468, Npcs.CYCLOPS_7270, Npcs.CYCLOPS_7271, Npcs.REVENANT_CYCLOPS).forEach { cyclops -> 
	set_combat_def(cyclops) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 55
			attack = 47
			strength = 50
			defence = 46
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 4652
			block = 4651
			death = 4653
		 }

		slayerData {
			levelRequirement = 0
			xp = 55.00
		 }
	 }
}
