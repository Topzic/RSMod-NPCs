package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ICE_GIANT, Npcs.ICE_GIANT_2086, Npcs.ICE_GIANT_2087, Npcs.ICE_GIANT_2088, Npcs.ICE_GIANT_2089, Npcs.ICE_GIANT_7878, Npcs.ICE_GIANT_7879, Npcs.ICE_GIANT_7880).forEach { icegiant -> 
	set_combat_def(icegiant) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 70
			attack = 40
			strength = 40
			defence = 40
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 29
			strengthBonus = 31
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 3
			defenceCrush = 2
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 4672
			block = 4671
			death = 4673
		 }

		slayerData {
			levelRequirement = 0
			xp = 70.00
		 }
	 }
}
