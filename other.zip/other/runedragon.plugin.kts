package gg.rsmod.plugins.content.npcs.npcInfo.runedragon

arrayOf(Npcs.RUNE_DRAGON_8027, Npcs.RUNE_DRAGON_8031, Npcs.RUNE_DRAGON_8091).forEach { runedragon -> 
	set_combat_def(runedragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 12
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 330
			attack = 284
			strength = 284
			defence = 276
			magic = 196
			ranged = 246
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 115
			defenceCrush = 90
			defenceMagic = 30
			defenceRanged = 95
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 1
			xp = 363.00
		 }
	 }
}
