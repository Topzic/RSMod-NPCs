package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GNOME_GUARD, Npcs.GNOME_GUARD_6081, Npcs.GNOME_GUARD_6082, Npcs.GNOME_GUARD_6574, Npcs.GNOME_GUARD_11199).forEach { gnomeguard -> 
	set_combat_def(gnomeguard) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 31
			attack = 17
			strength = 17
			defence = 17
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 8
			strengthBonus = 13
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 192
			block = 193
			death = 196
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
