package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.FREAKY_FORESTER, Npcs.FORESTER_HARD, Npcs.FORESTER, Npcs.JUNGLE_FORESTER, Npcs.JUNGLE_FORESTER_3955, Npcs.FORESTER_4076, Npcs.FREAKY_FORESTER_6748, Npcs.FORESTER_7238).forEach { forester -> 
	set_combat_def(forester) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 17
			attack = 14
			strength = 13
			defence = 8
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 4
			defenceSlash = 3
			defenceCrush = 5
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
