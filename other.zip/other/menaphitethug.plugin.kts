package gg.rsmod.plugins.content.npcs.npcInfo.menaphitethug

arrayOf(Npcs.MENAPHITE_THUG_3549, Npcs.MENAPHITE_THUG_3550).forEach { menaphitethug -> 
	set_combat_def(menaphitethug) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 60
			attack = 60
			strength = 50
			defence = 20
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 4
			strengthBonus = 9
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 9
			defenceSlash = 8
			defenceCrush = 10
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 137.00
		 }
	 }
}
