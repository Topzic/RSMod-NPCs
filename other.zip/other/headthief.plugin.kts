package gg.rsmod.plugins.content.npcs.npcInfo.headthief

arrayOf(Npcs.HEAD_THIEF).forEach { headthief -> 
	set_combat_def(headthief) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 37
			attack = 24
			strength = 18
			defence = 16
			magic = 0
			ranged = 2
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 8
			defenceSlash = 14
			defenceCrush = 15
			defenceMagic = 4
			defenceRanged = 9
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
