package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.NUCLEAR_SMOKE_DEVIL).forEach { nuclearsmokedevil ->
	set_combat_def(nuclearsmokedevil) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 1
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 3847
			block = 3848
			death = 3849
		 }

		slayerData {
			levelRequirement = 93
			xp = 2400.00
		 }
	 }
}
