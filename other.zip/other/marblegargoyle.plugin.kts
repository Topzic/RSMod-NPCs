package gg.rsmod.plugins.content.npcs.npcInfo.marblegargoyle

arrayOf(Npcs.MARBLE_GARGOYLE, Npcs.MARBLE_GARGOYLE_7408).forEach { marblegargoyle -> 
	set_combat_def(marblegargoyle) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 270
			attack = 230
			strength = 250
			defence = 190
			magic = 1
			ranged = 220
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 50
			defenceCrush = 0
			defenceMagic = 50
			defenceRanged = 50
		 }

		anims {
			attack = 7811
			block = 7814
			death = 7812
		 }

		slayerData {
			levelRequirement = 75
			xp = 276.00
		 }
	 }
}
