package gg.rsmod.plugins.content.npcs.npcInfo.dessourt

arrayOf(Npcs.DESSOURT, Npcs.DESSOURT_HARD, Npcs.DESSOURT_6372).forEach { dessourt -> 
	set_combat_def(dessourt) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 130
			attack = 99
			strength = 99
			defence = 99
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 50
			strengthBonus = 50
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 150
			defenceCrush = 150
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
