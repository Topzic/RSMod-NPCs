package gg.rsmod.plugins.content.npcs.npcInfo.duck

arrayOf(Npcs.DUCK, Npcs.DUCK_1839, Npcs.DUCK_2003, Npcs.DUCK_7473, Npcs.DUCK_10546, Npcs.DUCK_10547).forEach { duck ->
	set_combat_def(duck) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 3
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = -47
			strengthBonus = -42
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 42
			defenceSlash = 42
			defenceCrush = 42
			defenceMagic = 42
			defenceRanged = 42
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 3.00
		 }
	 }
}
