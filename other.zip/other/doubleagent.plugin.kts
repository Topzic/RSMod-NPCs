package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DOUBLE_AGENT, Npcs.DOUBLE_AGENT_1778, Npcs.DOUBLE_AGENT_7312).forEach { doubleagent -> 
	set_combat_def(doubleagent) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 80
			attack = 80
			strength = 43
			defence = 24
			magic = 24
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 3
			defenceSlash = 3
			defenceCrush = 3
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
