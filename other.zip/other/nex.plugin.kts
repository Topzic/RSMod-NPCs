package gg.rsmod.plugins.content.npcs.npcInfo.nex

arrayOf(Npcs.NEXLING_11276, Npcs.NEXLING_11277, Npcs.NEX, Npcs.NEX_11279, Npcs.NEX_11280, Npcs.NEX_11281, Npcs.NEX_11282).forEach { nex -> 
	set_combat_def(nex) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 2400
			attack = 150
			strength = 150
			defence = 150
			magic = 150
			ranged = 150
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 64
			magicDamageBonus = 0
			attackRanged = 140
			rangedStrengthBonus = 0
			defenceStab = 120
			defenceSlash = 180
			defenceCrush = 60
			defenceMagic = 600
			defenceRanged = 600
		 }

		anims {
			attack = 8595
			block = 1
			death = 8612
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
