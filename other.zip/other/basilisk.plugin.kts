package gg.rsmod.plugins.content.npcs.npcInfo.basilisk

arrayOf(Npcs.BASILISK_122, Npcs.BASILISK_417, Npcs.BASILISK_418, Npcs.BASILISK_9283, Npcs.BASILISK_9284, Npcs.BASILISK_9285, Npcs.BASILISK_9286).forEach { basilisk ->
	set_combat_def(basilisk) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 75
			attack = 30
			strength = 45
			defence = 75
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 0
			defenceMagic = 20
			defenceRanged = 0
		 }

		anims {
			attack = 1546
			block = 1547
			death = 1548
		 }

		slayerData {
			levelRequirement = 40
			xp = 75.00
		 }
	 }
}
