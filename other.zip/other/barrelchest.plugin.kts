package gg.rsmod.plugins.content.npcs.npcInfo.barrelchest

arrayOf(Npcs.BARRELCHEST, Npcs.BARRELCHEST_HARD, Npcs.BARRELCHEST_6342).forEach { barrelchest -> 
	set_combat_def(barrelchest) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 134
			attack = 170
			strength = 145
			defence = 140
			magic = 90
			ranged = 1
		 }

		bonuses {
			attackBonus = 80
			strengthBonus = 80
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 5894
			block = 5897
			death = 5898
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
