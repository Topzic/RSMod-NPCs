package gg.rsmod.plugins.content.npcs.npcInfo.imp

arrayOf(Npcs.IMP_3134, Npcs.IMP_5007, Npcs.IMP_5728).forEach { imp ->
	set_combat_def(imp) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 8
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = -42
			strengthBonus = -37
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 42
			defenceSlash = 42
			defenceCrush = 42
			defenceMagic = 42
			defenceRanged = 42
		 }

		anims {
			attack = 169
			block = 170
			death = 172
		 }

		slayerData {
			levelRequirement = 1
			xp = 450.00
		 }
	 }
}
