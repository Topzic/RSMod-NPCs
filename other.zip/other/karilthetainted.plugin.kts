package gg.rsmod.plugins.content.npcs.npcInfo.karilthetainted

arrayOf(Npcs.KARIL_THE_TAINTED).forEach { karilthetainted -> 
	set_combat_def(karilthetainted) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 100
			attack = 1
			strength = 1
			defence = 100
			magic = 1
			ranged = 100
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 134
			rangedStrengthBonus = 0
			defenceStab = 79
			defenceSlash = 71
			defenceCrush = 90
			defenceMagic = 106
			defenceRanged = 100
		 }

		anims {
			attack = 2075
			block = 424
			death = 4167
		 }

		slayerData {
			levelRequirement = 1
			xp = 20.00
		 }
	 }
}
