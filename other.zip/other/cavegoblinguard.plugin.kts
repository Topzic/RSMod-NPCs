package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CAVE_GOBLIN_GUARD, Npcs.CAVE_GOBLIN_GUARD_5335).forEach { cavegoblinguard -> 
	set_combat_def(cavegoblinguard) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 26
			attack = 22
			strength = 16
			defence = 22
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 4
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 15
			defenceCrush = 19
			defenceMagic = 3
			defenceRanged = 12
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 26.00
		 }
	 }
}
