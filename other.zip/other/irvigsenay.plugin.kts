package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.IRVIG_SENAY).forEach { irvigsenay -> 
	set_combat_def(irvigsenay) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 125
			attack = 76
			strength = 74
			defence = 81
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 29
			magicDamageBonus = 0
			attackRanged = 29
			rangedStrengthBonus = 0
			defenceStab = 27
			defenceSlash = 31
			defenceCrush = 29
			defenceMagic = 1
			defenceRanged = 29
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
