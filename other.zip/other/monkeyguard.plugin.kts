package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MONKEY_GUARD, Npcs.MONKEY_GUARD_5275, Npcs.MONKEY_GUARD_5276, Npcs.MONKEY_GUARD_6811, Npcs.MONKEY_GUARD_7122, Npcs.MONKEY_GUARD_7123, Npcs.MONKEY_GUARD_7124, Npcs.MONKEY_GUARD_7125, Npcs.MONKEY_GUARD_7126, Npcs.MONKEY_GUARD_7127, Npcs.MONKEY_GUARD_7128, Npcs.MONKEY_GUARD_7129, Npcs.MONKEY_GUARD_7130, Npcs.MONKEY_GUARD_7131, Npcs.MONKEY_GUARD_7132, Npcs.MONKEY_GUARD_7133, Npcs.MONKEY_GUARD_7134, Npcs.MONKEY_GUARD_7135, Npcs.MONKEY_GUARD_7136, Npcs.MONKEY_GUARD_7137, Npcs.MONKEY_GUARD_7138, Npcs.MONKEY_GUARD_7139, Npcs.MONKEY_GUARD_7140, Npcs.MONKEY_GUARD_7141, Npcs.MONKEY_GUARD_7142, Npcs.MONKEY_GUARD_7143).forEach { monkeyguard -> 
	set_combat_def(monkeyguard) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 130
			attack = 130
			strength = 130
			defence = 200
			magic = 130
			ranged = 1
		 }

		bonuses {
			attackBonus = 50
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 130.00
		 }
	 }
}
