package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.COCKATRICE_121, Npcs.COCKATRICE_419, Npcs.COCKATRICE_420).forEach { cockatrice -> 
	set_combat_def(cockatrice) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 37
			attack = 22
			strength = 37
			defence = 37
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 0
			defenceMagic = 10
			defenceRanged = 0
		 }

		anims {
			attack = 1562
			block = 1560
			death = 1563
		 }

		slayerData {
			levelRequirement = 25
			xp = 37.00
		 }
	 }
}
