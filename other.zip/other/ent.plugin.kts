package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ENT, Npcs.ENT_7234).forEach { ent ->
	set_combat_def(ent) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 75
			attack = 75
			strength = 75
			defence = 75
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 35
			magicDamageBonus = 0
			attackRanged = 35
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 40
			defenceRanged = 30
		 }

		anims {
			attack = 7145
			block = 7144
			death = 7146
		 }

		slayerData {
			levelRequirement = 1
			xp = 107.50
		 }
	 }
}
