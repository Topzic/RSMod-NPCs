package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MUMMY, Npcs.MUMMY_ASHES, Npcs.MUMMY_ASHES_719, Npcs.MUMMY_720, Npcs.MUMMY_721, Npcs.MUMMY_722, Npcs.MUMMY_723, Npcs.MUMMY_724, Npcs.MUMMY_725, Npcs.MUMMY_726, Npcs.MUMMY_727, Npcs.MUMMY_728, Npcs.MUMMY_949, Npcs.MUMMY_950, Npcs.MUMMY_951, Npcs.MUMMY_952, Npcs.MUMMY_953, Npcs.GUARDIAN_MUMMY, Npcs.ANNOYED_GUARDIAN_MUMMY, Npcs.MUMMY_5506, Npcs.MUMMY_7658, Npcs.MUMMY_7659, Npcs.MUMMY_7660, Npcs.MUMMY_7661, Npcs.MUMMY_7662).forEach { mummy -> 
	set_combat_def(mummy) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 90
			attack = 90
			strength = 30
			defence = 90
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 30
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 90
			defenceSlash = 90
			defenceCrush = 30
			defenceMagic = 90
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 910.00
		 }
	 }
}
