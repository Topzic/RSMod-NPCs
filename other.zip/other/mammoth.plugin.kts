package gg.rsmod.plugins.content.npcs.npcInfo.mammoth

arrayOf(Npcs.MAMMOTH).forEach { mammoth -> 
	set_combat_def(mammoth) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 130
			attack = 55
			strength = 60
			defence = 50
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 304
			block = 305
			death = 307
		 }

		slayerData {
			levelRequirement = 1
			xp = 130.00
		 }
	 }
}
