package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GARGOYLE_412, Npcs.GARGOYLE_413, Npcs.GARGOYLE_1543).forEach { gargoyle ->
	set_combat_def(gargoyle) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
		 }

		stats {
			hitpoints = 105
			attack = 75
			strength = 105
			defence = 107
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 0
			defenceMagic = 20
			defenceRanged = 20
		 }

		anims {
			attack = 1519
			block = 1517
			death = 1520
		 }

		slayerData {
			levelRequirement = 75
			xp = 105.00
		 }
	 }
}
