package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.REANIMATED_BLOODVELD).forEach { reanimatedbloodveld -> 
	set_combat_def(reanimatedbloodveld) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 35
			attack = 75
			strength = 45
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 20
			defenceMagic = 20
			defenceRanged = 20
		 }

		anims {
			attack = 1552
			block = 1550
			death = 1553
		 }

		slayerData {
			levelRequirement = 1
			xp = 104.00
		 }
	 }
}
