package gg.rsmod.plugins.content.npcs.npcInfo.kalphitequeen

arrayOf(Npcs.KALPHITE_QUEEN, Npcs.KALPHITE_QUEEN_963, Npcs.KALPHITE_QUEEN_965, Npcs.KALPHITE_QUEEN_4303, Npcs.KALPHITE_QUEEN_4304, Npcs.KALPHITE_QUEEN_6500, Npcs.KALPHITE_QUEEN_6501).forEach { kalphitequeen -> 
	set_combat_def(kalphitequeen) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 255
			attack = 300
			strength = 300
			defence = 300
			magic = 150
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 50
			defenceCrush = 10
			defenceMagic = 100
			defenceRanged = 100
		 }

		anims {
			attack = 1178
			block = 6237
			death = 6233
		 }

		slayerData {
			levelRequirement = 0
			xp = 535.50
		 }
	 }
}
