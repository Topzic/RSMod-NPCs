package gg.rsmod.plugins.content.npcs.npcInfo.scion

arrayOf(Npcs.LUSCION, Npcs.SCION, Npcs.SCION_6177).forEach { scion -> 
	set_combat_def(scion) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 50
			attack = 120
			strength = 90
			defence = 80
			magic = 1
			ranged = 100
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 30
			magicDamageBonus = 0
			attackRanged = 30
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 10
			defenceRanged = 0
		 }

		anims {
			attack = 7126
			block = 7128
			death = 7129
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
