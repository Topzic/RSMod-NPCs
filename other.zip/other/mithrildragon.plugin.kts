package gg.rsmod.plugins.content.npcs.npcInfo.mithrildragon

arrayOf(Npcs.MITHRIL_DRAGON, Npcs.MITHRIL_DRAGON_8088, Npcs.MITHRIL_DRAGON_8089).forEach { mithrildragon -> 
	set_combat_def(mithrildragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 255
			attack = 268
			strength = 268
			defence = 268
			magic = 168
			ranged = 168
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 100
			defenceCrush = 70
			defenceMagic = 30
			defenceRanged = 90
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 1
			xp = 273.00
		 }
	 }
}
