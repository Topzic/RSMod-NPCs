package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.INFERNAL_MAGE_443, Npcs.INFERNAL_MAGE_444, Npcs.INFERNAL_MAGE_445, Npcs.INFERNAL_MAGE_446, Npcs.INFERNAL_MAGE_447).forEach { infernalmage -> 
	set_combat_def(infernalmage) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			neverAggro()
		 }

		stats {
			hitpoints = 60
			attack = 1
			strength = 1
			defence = 60
			magic = 75
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 40
			defenceRanged = 0
		 }

		anims {
			attack = 1162
			block = 420
			death = 836
		 }

		slayerData {
			levelRequirement = 45
			xp = 60.00
		 }
	 }
}
