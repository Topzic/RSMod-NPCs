package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CRAWLING_HAND_120, Npcs.CRAWLING_HAND_448, Npcs.CRAWLING_HAND_449, Npcs.CRAWLING_HAND_450, Npcs.CRAWLING_HAND_451, Npcs.CRAWLING_HAND_452, Npcs.CRAWLING_HAND_453, Npcs.CRAWLING_HAND_454, Npcs.CRAWLING_HAND_455, Npcs.CRAWLING_HAND_456, Npcs.CRAWLING_HAND_457).forEach { crawlinghand -> 
	set_combat_def(crawlinghand) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 15
			attack = 7
			strength = 3
			defence = 3
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1592
			block = 1591
			death = 1590
		 }

		slayerData {
			levelRequirement = 5
			xp = 12.00
		 }
	 }
}
