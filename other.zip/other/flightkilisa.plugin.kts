package gg.rsmod.plugins.content.npcs.npcInfo.flightkilisa

arrayOf(Npcs.FLIGHT_KILISA).forEach { flightkilisa -> 
	set_combat_def(flightkilisa) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 159
			attack = 124
			strength = 118
			defence = 175
			magic = 50
			ranged = 169
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 6957
			block = 6958
			death = 6959
		 }

		slayerData {
			levelRequirement = 1
			xp = 132.50
		 }
	 }
}
