package gg.rsmod.plugins.content.npcs.npcInfo.kob

arrayOf(Npcs.JAGBAKOBA, Npcs.JAGBAKOBA_6428, Npcs.JAGBAKOBA_6429, Npcs.KOB, Npcs.KOB_7107, Npcs.SKOBLIN).forEach { kob -> 
	set_combat_def(kob) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 200
			attack = 180
			strength = 175
			defence = 80
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 200
			magicDamageBonus = 0
			attackRanged = 200
			rangedStrengthBonus = 0
			defenceStab = 85
			defenceSlash = 85
			defenceCrush = 90
			defenceMagic = 200
			defenceRanged = 200
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
