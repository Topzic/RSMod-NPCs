package gg.rsmod.plugins.content.npcs.npcInfo.khazardwarlord

arrayOf(Npcs.KHAZARD_WARLORD_HARD, Npcs.KHAZARD_WARLORD, Npcs.KHAZARD_WARLORD_7621, Npcs.KHAZARD_WARLORD_7622).forEach { khazardwarlord -> 
	set_combat_def(khazardwarlord) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 170
			attack = 75
			strength = 78
			defence = 80
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
