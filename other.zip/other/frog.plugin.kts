package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.FROG, Npcs.FROG_479, Npcs.FROG_3290, Npcs.FROG_5429, Npcs.FROG_5430, Npcs.FROG_5431, Npcs.FROG_5432, Npcs.FROG_5833, Npcs.FROG_8702, Npcs.FROG_10700).forEach { frog ->
	set_combat_def(frog) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 8
			attack = 5
			strength = 4
			defence = 3
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1793
			block = 1794
			death = 1795
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
