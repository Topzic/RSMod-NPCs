package gg.rsmod.plugins.content.npcs.npcInfo.iorwerthwarrior

arrayOf(Npcs.IORWERTH_WARRIOR, Npcs.IORWERTH_WARRIOR_8759, Npcs.IORWERTH_WARRIOR_8877, Npcs.IORWERTH_WARRIOR_8879, Npcs.IORWERTH_WARRIOR_8881, Npcs.IORWERTH_WARRIOR_8882, Npcs.IORWERTH_WARRIOR_8883, Npcs.IORWERTH_WARRIOR_8884, Npcs.IORWERTH_WARRIOR_8922, Npcs.IORWERTH_WARRIOR_8938, Npcs.IORWERTH_WARRIOR_8939, Npcs.IORWERTH_WARRIOR_8955, Npcs.IORWERTH_WARRIOR_8956, Npcs.IORWERTH_WARRIOR_9502, Npcs.IORWERTH_WARRIOR_9503).forEach { iorwerthwarrior -> 
	set_combat_def(iorwerthwarrior) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 105
			attack = 95
			strength = 95
			defence = 80
			magic = 1
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 60
			defenceRanged = 50
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 0
			xp = 107.50
		 }
	 }
}
