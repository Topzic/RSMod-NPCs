package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.AVIANSIE, Npcs.AVIANSIE_3170, Npcs.AVIANSIE_3171, Npcs.AVIANSIE_3172, Npcs.AVIANSIE_3173, Npcs.AVIANSIE_3174, Npcs.AVIANSIE_3175, Npcs.AVIANSIE_3176, Npcs.AVIANSIE_3177, Npcs.AVIANSIE_3178, Npcs.AVIANSIE_3179, Npcs.AVIANSIE_3180, Npcs.AVIANSIE_3181, Npcs.AVIANSIE_3182, Npcs.AVIANSIE_3183, Npcs.REANIMATED_AVIANSIE).forEach { aviansie -> 
	set_combat_def(aviansie) {

		configs {
			attackSpeed = 4
			respawnDelay = 72
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 70
			attack = 1
			strength = 1
			defence = 70
			magic = 1
			ranged = 71
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 6956
			block = 6955
			death = 6959
		 }

		slayerData {
			levelRequirement = 0
			xp = 70.00
		 }
	 }
}
