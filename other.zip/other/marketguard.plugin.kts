package gg.rsmod.plugins.content.npcs.npcInfo.marketguard

arrayOf(Npcs.MARKET_GUARD, Npcs.MARKET_GUARD_3949, Npcs.MARKET_GUARD_5732).forEach { marketguard -> 
	set_combat_def(marketguard) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 50
			attack = 40
			strength = 40
			defence = 40
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 40
			magicDamageBonus = 0
			attackRanged = 40
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 50
			defenceCrush = 50
			defenceMagic = 50
			defenceRanged = 50
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
