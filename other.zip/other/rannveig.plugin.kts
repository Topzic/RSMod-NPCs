package gg.rsmod.plugins.content.npcs.npcInfo.rannveig

arrayOf(Npcs.RANNVEIG).forEach { rannveig -> 
	set_combat_def(rannveig) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 1
			attack = 3
			strength = 3
			defence = 3
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 12
			defenceSlash = 12
			defenceCrush = 12
			defenceMagic = 12
			defenceRanged = 12
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
