package gg.rsmod.plugins.content.npcs.npcInfo.lizardmanbrute

arrayOf(Npcs.LIZARDMAN_BRUTE, Npcs.LIZARDMAN_BRUTE_6919, Npcs.LIZARDMAN_BRUTE_8564, Npcs.LIZARDMAN_BRUTE_10947).forEach { lizardmanbrute -> 
	set_combat_def(lizardmanbrute) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 60
			attack = 65
			strength = 65
			defence = 65
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 34
			strengthBonus = 30
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 34
			rangedStrengthBonus = 30
			defenceStab = 10
			defenceSlash = 30
			defenceCrush = 10
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 7192
			block = 7194
			death = 7196
		 }

		slayerData {
			levelRequirement = 0
			xp = 60.00
		 }
	 }
}
