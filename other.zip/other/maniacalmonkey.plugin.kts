package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MANIACAL_MONKEY_6803, Npcs.MANIACAL_MONKEY_7118, Npcs.MANIACAL_MONKEY_7212, Npcs.MANIACAL_MONKEY_7213, Npcs.MANIACAL_MONKEY_7214, Npcs.MANIACAL_MONKEY_7215, Npcs.MANIACAL_MONKEY_7216).forEach { maniacalmonkey ->
	set_combat_def(maniacalmonkey) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 65
			attack = 200
			strength = 175
			defence = 10
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 65.00
		 }
	 }
}
