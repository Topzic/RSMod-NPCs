package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CORPOREAL_BEAST).forEach { corporealbeast -> 
	set_combat_def(corporealbeast) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 2000
			attack = 320
			strength = 320
			defence = 310
			magic = 350
			ranged = 150
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 50
			magicDamageBonus = 0
			attackRanged = 50
			rangedStrengthBonus = 0
			defenceStab = 25
			defenceSlash = 200
			defenceCrush = 100
			defenceMagic = 150
			defenceRanged = 230
		 }

		anims {
			attack = 1683
			block = 1677
			death = 1676
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
