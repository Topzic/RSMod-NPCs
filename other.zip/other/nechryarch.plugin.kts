package gg.rsmod.plugins.content.npcs.npcInfo.nechryarch

arrayOf(Npcs.NECHRYARCH).forEach { nechryarch -> 
	set_combat_def(nechryarch) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 320
			attack = 310
			strength = 260
			defence = 140
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 30
			defenceCrush = 30
			defenceMagic = 0
			defenceRanged = 30
		 }

		anims {
			attack = 6368
			block = 6370
			death = 6369
		 }

		slayerData {
			levelRequirement = 80
			xp = 328.00
		 }
	 }
}
