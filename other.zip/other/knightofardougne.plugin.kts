package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.KNIGHT_OF_ARDOUGNE_3297, Npcs.KNIGHT_OF_ARDOUGNE_3300, Npcs.KNIGHT_OF_ARDOUGNE_8799, Npcs.KNIGHT_OF_ARDOUGNE_8800, Npcs.KNIGHT_OF_ARDOUGNE_8801, Npcs.KNIGHT_OF_ARDOUGNE_8851, Npcs.KNIGHT_OF_ARDOUGNE_8852, Npcs.KNIGHT_OF_ARDOUGNE_8854, Npcs.KNIGHT_OF_ARDOUGNE_8855).forEach { knightofardougne -> 
	set_combat_def(knightofardougne) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 52
			attack = 38
			strength = 40
			defence = 31
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 8
			strengthBonus = 10
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 39
			defenceSlash = 40
			defenceCrush = 36
			defenceMagic = 11
			defenceRanged = 36
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 843.00
		 }
	 }
}
