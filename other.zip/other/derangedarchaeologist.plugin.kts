package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DERANGED_ARCHAEOLOGIST).forEach { derangedarchaeologist -> 
	set_combat_def(derangedarchaeologist) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 200
			attack = 280
			strength = 90
			defence = 240
			magic = 1
			ranged = 180
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 250
			magicDamageBonus = 0
			attackRanged = 75
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 50
			defenceMagic = 300
			defenceRanged = 300
		 }

		anims {
			attack = 3353
			block = 425
			death = 2304
		 }

		slayerData {
			levelRequirement = 1
			xp = 275.00
		 }
	 }
}
