package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GROWLER).forEach { growler -> 
	set_combat_def(growler) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 146
			attack = 100
			strength = 101
			defence = 120
			magic = 150
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 10
			magicDamageBonus = 0
			attackRanged = 10
			rangedStrengthBonus = 0
			defenceStab = 12
			defenceSlash = 14
			defenceCrush = 14
			defenceMagic = 18
			defenceRanged = 5
		 }

		anims {
			attack = 7037
			block = 7035
			death = 7034
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
