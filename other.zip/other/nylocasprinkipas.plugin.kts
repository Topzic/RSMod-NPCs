package gg.rsmod.plugins.content.npcs.npcInfo.nylocasprinkipas

arrayOf(Npcs.NYLOCAS_PRINKIPAS, Npcs.NYLOCAS_PRINKIPAS_10804, Npcs.NYLOCAS_PRINKIPAS_10805, Npcs.NYLOCAS_PRINKIPAS_10806).forEach { nylocasprinkipas -> 
	set_combat_def(nylocasprinkipas) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 400
			attack = 200
			strength = 175
			defence = 25
			magic = 25
			ranged = 175
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 30
			attackMagic = 300
			magicDamageBonus = 300
			attackRanged = 0
			rangedStrengthBonus = 30
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 8097
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
