package gg.rsmod.plugins.content.npcs.npcInfo.crazyarchaeologist

arrayOf(Npcs.CRAZY_ARCHAEOLOGIST).forEach { crazyarchaeologist -> 
	set_combat_def(crazyarchaeologist) {

		configs {
			attackSpeed = 3
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 225
			attack = 160
			strength = 90
			defence = 240
			magic = 1
			ranged = 180
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 250
			magicDamageBonus = 0
			attackRanged = 75
			rangedStrengthBonus = 0
			defenceStab = 5
			defenceSlash = 5
			defenceCrush = 30
			defenceMagic = 50
			defenceRanged = 250
		 }

		anims {
			attack = 3353
			block = 425
			death = 2304
		 }

		slayerData {
			levelRequirement = 1
			xp = 275.00
		 }
	 }
}
