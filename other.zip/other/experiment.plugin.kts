package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.EXPERIMENT, Npcs.EXPERIMENT_1274, Npcs.EXPERIMENT_1275, Npcs.WITCHS_EXPERIMENT, Npcs.WITCHS_EXPERIMENT_SECOND_FORM, Npcs.WITCHS_EXPERIMENT_THIRD_FORM, Npcs.WITCHS_EXPERIMENT_FOURTH_FORM, Npcs.EXPERIMENT_NO2, Npcs.WITCHS_EXPERIMENT_HARD, Npcs.WITCHS_EXPERIMENT_SECOND_FORM_HARD, Npcs.WITCHS_EXPERIMENT_THIRD_FORM_HARD, Npcs.WITCHS_EXPERIMENT_FOURTH_FORM_HARD, Npcs.WITCHS_EXPERIMENT_6394, Npcs.WITCHS_EXPERIMENT_SECOND_FORM_6395, Npcs.WITCHS_EXPERIMENT_THIRD_FORM_6396, Npcs.WITCHS_EXPERIMENT_FOURTH_FORM_6397).forEach { experiment -> 
	set_combat_def(experiment) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 40
			attack = 40
			strength = 50
			defence = 50
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1626
			block = 1627
			death = 1628
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
