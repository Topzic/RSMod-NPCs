package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ROCK_LOBSTER).forEach { rocklobster -> 
	set_combat_def(rocklobster) {

		configs {
			attackSpeed = 2
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 150
			attack = 100
			strength = 100
			defence = 100
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 100
			defenceSlash = 100
			defenceCrush = 50
			defenceMagic = 50
			defenceRanged = 150
		 }

		anims {
			attack = 2859
			block = 2860
			death = 2862
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
