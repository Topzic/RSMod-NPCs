package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DAGANNOTH_REX, Npcs.DAGANNOTH_REX_6498, Npcs.DAGANNOTH_REX_JR, Npcs.DAGANNOTH_REX_JR_6641).forEach { dagannothrex -> 
	set_combat_def(dagannothrex) {

		configs {
			attackSpeed = 4
			respawnDelay = 60
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 255
			attack = 255
			strength = 255
			defence = 255
			magic = 0
			ranged = 255
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 255
			defenceSlash = 255
			defenceCrush = 255
			defenceMagic = 10
			defenceRanged = 255
		 }

		anims {
			attack = 2853
			block = 2852
			death = 2856
		 }

		slayerData {
			levelRequirement = 0
			xp = 331.40
		 }
	 }
}
