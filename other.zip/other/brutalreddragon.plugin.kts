package gg.rsmod.plugins.content.npcs.npcInfo.brutalreddragon

arrayOf(Npcs.BRUTAL_RED_DRAGON, Npcs.BRUTAL_RED_DRAGON_8087).forEach { brutalreddragon -> 
	set_combat_def(brutalreddragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 285
			attack = 310
			strength = 210
			defence = 198
			magic = 250
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 60
			defenceRanged = 50
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 1
			xp = 306.20
		 }
	 }
}
