package gg.rsmod.plugins.content.npcs.npcInfo.giantscarab

arrayOf(Npcs.GIANT_SCARAB, Npcs.GIANT_SCARAB_798, Npcs.GIANT_SCARAB_HARD, Npcs.GIANT_SCARAB_6343).forEach { giantscarab -> 
	set_combat_def(giantscarab) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 130
			attack = 169
			strength = 190
			defence = 169
			magic = 1
			ranged = 190
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 70
			defenceSlash = 99
			defenceCrush = 99
			defenceMagic = 159
			defenceRanged = 149
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 137.00
		 }
	 }
}
