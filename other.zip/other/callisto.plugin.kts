package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CALLISTO_CUB_497, Npcs.CALLISTO_CUB_5558, Npcs.CALLISTO, Npcs.CALLISTO_6609).forEach { callisto -> 
	set_combat_def(callisto) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 255
			attack = 350
			strength = 370
			defence = 440
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 135
			defenceSlash = 104
			defenceCrush = 175
			defenceMagic = 900
			defenceRanged = 230
		 }

		anims {
			attack = 4925
			block = 4927
			death = 4929
		 }

		slayerData {
			levelRequirement = 0
			xp = 312.00
		 }
	 }
}
