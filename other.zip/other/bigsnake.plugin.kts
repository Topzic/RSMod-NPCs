package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BIG_SNAKE).forEach { bigsnake -> 
	set_combat_def(bigsnake) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 120
			attack = 60
			strength = 60
			defence = 60
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 66
			magicDamageBonus = 0
			attackRanged = 66
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 3538
			block = 3539
			death = 3540
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
