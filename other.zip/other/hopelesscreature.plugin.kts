package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.HOPELESS_CREATURE, Npcs.HOPELESS_CREATURE_1073, Npcs.HOPELESS_CREATURE_1074, Npcs.HOPELESS_CREATURE_4695).forEach { hopelesscreature -> 
	set_combat_def(hopelesscreature) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 25
			attack = 38
			strength = 36
			defence = 39
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
