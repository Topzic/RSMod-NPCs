package gg.rsmod.plugins.content.npcs.npcInfo.chaosdruidwarrior

arrayOf(Npcs.CHAOS_DRUID_WARRIOR).forEach { chaosdruidwarrior -> 
	set_combat_def(chaosdruidwarrior) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 40
			attack = 32
			strength = 34
			defence = 25
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 9
			magicDamageBonus = 0
			attackRanged = 9
			rangedStrengthBonus = 0
			defenceStab = 13
			defenceSlash = 17
			defenceCrush = 14
			defenceMagic = 4
			defenceRanged = 14
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 400.00
		 }
	 }
}
