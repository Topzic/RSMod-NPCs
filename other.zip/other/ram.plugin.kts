package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.RAM, Npcs.RAM_1262, Npcs.RAM_1263, Npcs.RAM_1264, Npcs.RAM_1265).forEach { ram ->
	set_combat_def(ram) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 8
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = -15
			strengthBonus = -15
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 21
			defenceSlash = 21
			defenceCrush = 21
			defenceMagic = 21
			defenceRanged = 21
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
