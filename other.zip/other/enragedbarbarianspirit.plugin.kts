package gg.rsmod.plugins.content.npcs.npcInfo.enragedbarbarianspirit

arrayOf(Npcs.ENRAGED_BARBARIAN_SPIRIT).forEach { enragedbarbarianspirit -> 
	set_combat_def(enragedbarbarianspirit) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 190
			attack = 150
			strength = 140
			defence = 100
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 9
			magicDamageBonus = 0
			attackRanged = 9
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 3
			defenceCrush = 2
			defenceMagic = 3
			defenceRanged = 2
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 38.00
		 }
	 }
}
