package gg.rsmod.plugins.content.npcs.npcInfo.pirate

arrayOf(Npcs.PIRATE, Npcs.PIRATE_522, Npcs.PIRATE_523, Npcs.PIRATE_524, Npcs.PIRATE_1447, Npcs.PIRATE_4023, Npcs.PIRATE_4024, Npcs.PIRATE_4025, Npcs.PIRATE_4026, Npcs.PIRATE_4027, Npcs.PIRATE_4028, Npcs.PIRATE_4029, Npcs.PIRATE_4030, Npcs.PIRATE_4031, Npcs.PIRATE_4032, Npcs.PIRATE_4033, Npcs.PIRATE_4034, Npcs.PIRATE_4035, Npcs.PIRATE_4036, Npcs.PIRATE_4037, Npcs.PIRATE_4038, Npcs.PIRATE_4039, Npcs.PIRATE_4040, Npcs.PIRATE_4041, Npcs.PIRATE_4042, Npcs.PIRATE_4043, Npcs.PIRATE_4044, Npcs.PIRATE_4045, Npcs.PIRATE_4046, Npcs.PIRATE_4047, Npcs.PIRATE_4048, Npcs.PIRATE_4049, Npcs.PIRATE_4050, Npcs.PIRATE_4051, Npcs.PIRATE_4052, Npcs.PIRATE_6993, Npcs.PIRATE_6994, Npcs.PIRATE_6995, Npcs.PIRATE_6998, Npcs.PIRATE_7282, Npcs.PIRATE_7917, Npcs.PIRATE_7918).forEach { pirate ->
	set_combat_def(pirate) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 20
			attack = 21
			strength = 21
			defence = 21
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 8
			strengthBonus = 10
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 3
			defenceSlash = 2
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 20.00
		 }
	 }
}
