package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CAVE_KRAKEN_492).forEach { cavekraken -> 
	set_combat_def(cavekraken) {

		configs {
			attackSpeed = 6
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 125
			attack = 1
			strength = 1
			defence = 150
			magic = 120
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 63
			defenceRanged = 100
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 87
			xp = 125.00
		 }
	 }
}
