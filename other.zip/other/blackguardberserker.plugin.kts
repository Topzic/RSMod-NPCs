package gg.rsmod.plugins.content.npcs.npcInfo.blackguardberserker

arrayOf(Npcs.BLACK_GUARD_BERSERKER, Npcs.BLACK_GUARD_BERSERKER_6050, Npcs.BLACK_GUARD_BERSERKER_6051, Npcs.BLACK_GUARD_BERSERKER_6052).forEach { blackguardberserker -> 
	set_combat_def(blackguardberserker) {

		configs {
			attackSpeed = 3
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 50
			attack = 60
			strength = 60
			defence = 60
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 55
			strengthBonus = 55
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 60
			defenceSlash = 60
			defenceCrush = 60
			defenceMagic = 0
			defenceRanged = 60
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 50.00
		 }
	 }
}
