package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.HUSK, Npcs.HUSK_9455, Npcs.HUSK_9466, Npcs.HUSK_9467).forEach { husk -> 
	set_combat_def(husk) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 20
			attack = 1
			strength = 1
			defence = 20
			magic = 80
			ranged = 80
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 20
			defenceMagic = 80
			defenceRanged = 80
		 }

		anims {
			attack = 8564
			block = 1
			death = 8566
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
