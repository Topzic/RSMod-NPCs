package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ANGRY_GIANT_RAT, Npcs.GIANT_RAT, Npcs.GIANT_RAT_2511, Npcs.GIANT_RAT_2512, Npcs.GIANT_RAT_2857, Npcs.GIANT_RAT_2858, Npcs.GIANT_RAT_2859, Npcs.GIANT_RAT_2860, Npcs.GIANT_RAT_2861, Npcs.GIANT_RAT_2862, Npcs.GIANT_RAT_3313, Npcs.GIANT_RAT_3314, Npcs.GIANT_RAT_3315, Npcs.ANGRY_GIANT_RAT_4689, Npcs.ANGRY_GIANT_RAT_4690, Npcs.GIANT_RAT_9483).forEach { giantrat ->
	set_combat_def(giantrat) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 3
			attack = 1
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 100
			defenceSlash = 100
			defenceCrush = 100
			defenceMagic = 0
			defenceRanged = 100
		 }

		anims {
			attack = 4933
			block = 4934
			death = 4935
		 }

		slayerData {
			levelRequirement = 0
			xp = 3.00
		 }
	 }
}
