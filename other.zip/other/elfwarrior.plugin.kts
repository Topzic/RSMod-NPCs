package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ELF_WARRIOR, Npcs.ELF_WARRIOR_5294).forEach { elfwarrior -> 
	set_combat_def(elfwarrior) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 105
			attack = 95
			strength = 95
			defence = 80
			magic = 1
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 60
			defenceRanged = 50
		 }

		anims {
			attack = 426
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 107.50
		 }
	 }
}
