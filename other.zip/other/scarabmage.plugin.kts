package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.SCARAB_MAGE, Npcs.SCARAB_MAGE_799, Npcs.SCARAB_MAGE_11508, Npcs.SCARAB_MAGE_11510, Npcs.SCARAB_MAGE_11511).forEach { scarabmage -> 
	set_combat_def(scarabmage) {

		configs {
			attackSpeed = 5
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 50
			attack = 90
			strength = 90
			defence = 90
			magic = 70
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 70
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 40
			defenceSlash = 90
			defenceCrush = 90
			defenceMagic = 34
			defenceRanged = 0
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 0
			xp = 512.00
		 }
	 }
}
