package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ORK, Npcs.ORK_2105, Npcs.ORK_2106, Npcs.ORK_2107, Npcs.ORK_2237, Npcs.ORK_2238, Npcs.ORK_2239, Npcs.ORK_2240).forEach { ork ->
	set_combat_def(ork) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 110
			attack = 100
			strength = 100
			defence = 60
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 19
			magicDamageBonus = 0
			attackRanged = 19
			rangedStrengthBonus = 0
			defenceStab = 12
			defenceSlash = 14
			defenceCrush = 13
			defenceMagic = 5
			defenceRanged = 13
		 }

		anims {
			attack = 4320
			block = 4322
			death = 4321
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
