package gg.rsmod.plugins.content.npcs.npcInfo.glod

arrayOf(Npcs.GLOD, Npcs.GLOD_HARD, Npcs.GLOD_6358).forEach { glod -> 
	set_combat_def(glod) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 160
			attack = 115
			strength = 120
			defence = 110
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 105
			defenceSlash = 110
			defenceCrush = 130
			defenceMagic = 125
			defenceRanged = 100
		 }

		anims {
			attack = 6501
			block = 6503
			death = 6502
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
