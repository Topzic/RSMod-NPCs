package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ABYSSAL_GUARDIAN, Npcs.ABYSSAL_GUARDIAN_11405, Npcs.ABYSSAL_GUARDIAN_11453).forEach { abyssalguardian -> 
	set_combat_def(abyssalguardian) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 55
			attack = 30
			strength = 90
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 15
			magicDamageBonus = 0
			attackRanged = 15
			rangedStrengthBonus = 0
			defenceStab = 70
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 150
			defenceRanged = 70
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
