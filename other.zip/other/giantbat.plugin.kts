package gg.rsmod.plugins.content.npcs.npcInfo.giantbat

arrayOf(Npcs.GIANT_BAT, Npcs.GIANT_BAT_4504, Npcs.GIANT_BAT_4562, Npcs.GIANT_BAT_5791, Npcs.GIANT_BAT_6824).forEach { giantbat -> 
	set_combat_def(giantbat) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 32
			attack = 22
			strength = 22
			defence = 22
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 12
			defenceMagic = 10
			defenceRanged = 8
		 }

		anims {
			attack = 4915
			block = 4916
			death = 4917
		 }

		slayerData {
			levelRequirement = 0
			xp = 32.00
		 }
	 }
}
