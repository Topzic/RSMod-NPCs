package gg.rsmod.plugins.content.npcs.npcInfo.hydra

arrayOf(Npcs.HYDRA_8609).forEach { hydra ->
	set_combat_def(hydra) {

		configs {
			attackSpeed = 6
			respawnDelay = 18
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 300
			attack = 1
			strength = 1
			defence = 100
			magic = 210
			ranged = 210
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 160
			defenceSlash = 160
			defenceCrush = 160
			defenceMagic = 160
			defenceRanged = 0
		 }

		anims {
			attack = 8263
			block = 1
			death = 8264
		 }

		slayerData {
			levelRequirement = 95
			xp = 322.50
		 }
	 }
}
