package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.EARTH_WARRIOR, Npcs.EARTH_WARRIOR_CHAMPION).forEach { earthwarrior -> 
	set_combat_def(earthwarrior) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 54
			attack = 42
			strength = 42
			defence = 42
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 30
			defenceSlash = 40
			defenceCrush = 20
			defenceMagic = 10
			defenceRanged = 30
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 54.00
		 }
	 }
}
