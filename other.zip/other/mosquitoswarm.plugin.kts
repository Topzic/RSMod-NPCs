package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MOSQUITO_SWARM, Npcs.MOSQUITO_SWARM_6402).forEach { mosquitoswarm -> 
	set_combat_def(mosquitoswarm) {

		configs {
			attackSpeed = 2
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 9
			attack = 10
			strength = 1
			defence = 45
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 2
			defenceSlash = 2
			defenceCrush = 5
			defenceMagic = 2
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 35.00
		 }
	 }
}
