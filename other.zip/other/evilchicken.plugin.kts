package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.EVIL_CHICKEN, Npcs.EVIL_CHICKEN_HARD, Npcs.EVIL_CHICKEN_6367, Npcs.EVIL_CHICKEN_6739).forEach { evilchicken -> 
	set_combat_def(evilchicken) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 120
			attack = 0
			strength = 0
			defence = 126
			magic = 200
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 3.00
		 }
	 }
}
