package gg.rsmod.plugins.content.npcs.npcInfo.drake

arrayOf(Npcs.DRAKE_2004, Npcs.DRAKE_8612, Npcs.DRAKE_8613).forEach { drake ->
	set_combat_def(drake) {

		configs {
			attackSpeed = 4
			respawnDelay = 18
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 250
			attack = 140
			strength = 118
			defence = 120
			magic = 112
			ranged = 140
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 60
			defenceSlash = 60
			defenceCrush = 60
			defenceMagic = 20
			defenceRanged = 100
		 }

		anims {
			attack = 8275
			block = 1
			death = 8279
		 }

		slayerData {
			levelRequirement = 84
			xp = 262.50
		 }
	 }
}
