package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.IORWERTH_ARCHER, Npcs.IORWERTH_ARCHER_8760, Npcs.IORWERTH_ARCHER_8878, Npcs.IORWERTH_ARCHER_8880, Npcs.IORWERTH_ARCHER_8885, Npcs.IORWERTH_ARCHER_8886, Npcs.IORWERTH_ARCHER_8923, Npcs.IORWERTH_ARCHER_8936, Npcs.IORWERTH_ARCHER_8937, Npcs.IORWERTH_ARCHER_8953, Npcs.IORWERTH_ARCHER_8954).forEach { iorwertharcher -> 
	set_combat_def(iorwertharcher) {

		configs {
			attackSpeed = 5
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
		 }

		stats {
			hitpoints = 105
			attack = 10
			strength = 10
			defence = 80
			magic = 1
			ranged = 90
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 8
			defenceStab = 50
			defenceSlash = 50
			defenceCrush = 50
			defenceMagic = 60
			defenceRanged = 70
		 }

		anims {
			attack = 426
			block = 378
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 105.00
		 }
	 }
}
