package gg.rsmod.plugins.content.npcs.npcInfo.feverspider

arrayOf(Npcs.FEVER_SPIDER_626).forEach { feverspider -> 
	set_combat_def(feverspider) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 40
			attack = 60
			strength = 30
			defence = 40
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 1
			magicDamageBonus = 0
			attackRanged = 1
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 15
			defenceCrush = 10
			defenceMagic = 15
			defenceRanged = 15
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 42
			xp = 40.00
		 }
	 }
}
