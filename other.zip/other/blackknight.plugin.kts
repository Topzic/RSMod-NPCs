package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BLACK_KNIGHT, Npcs.BLACK_KNIGHT_517, Npcs.BLACK_KNIGHT_1545, Npcs.BLACK_KNIGHT_4331, Npcs.BLACK_KNIGHT_CAPTAIN, Npcs.BLACK_KNIGHT_4934, Npcs.BLACK_KNIGHT_4959, Npcs.BLACK_KNIGHT_4960).forEach { blackknight ->
	set_combat_def(blackknight) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 42
			attack = 25
			strength = 25
			defence = 25
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 18
			magicDamageBonus = 0
			attackRanged = 18
			rangedStrengthBonus = 0
			defenceStab = 73
			defenceSlash = 76
			defenceCrush = 70
			defenceMagic = 11
			defenceRanged = 72
		 }

		anims {
			attack = 390
			block = 388
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 42.00
		 }
	 }
}
