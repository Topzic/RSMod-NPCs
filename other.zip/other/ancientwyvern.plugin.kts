package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ANCIENT_WYVERN).forEach { ancientwyvern -> 
	set_combat_def(ancientwyvern) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 300
			attack = 150
			strength = 150
			defence = 150
			magic = 90
			ranged = 90
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 70
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 140
			defenceRanged = 120
		 }

		anims {
			attack = 7651
			block = 7659
			death = 7652
		 }

		slayerData {
			levelRequirement = 82
			xp = 315.00
		 }
	 }
}
