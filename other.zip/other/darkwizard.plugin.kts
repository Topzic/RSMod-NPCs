package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DARK_WIZARD, Npcs.DARK_WIZARD_512, Npcs.DARK_WIZARD_2056, Npcs.DARK_WIZARD_2057, Npcs.DARK_WIZARD_2058, Npcs.DARK_WIZARD_2059, Npcs.DARK_WIZARD_5086, Npcs.DARK_WIZARD_5087, Npcs.DARK_WIZARD_5088, Npcs.DARK_WIZARD_5089, Npcs.DARK_WIZARD_6997, Npcs.DARK_WIZARD_7064, Npcs.DARK_WIZARD_7065).forEach { darkwizard -> 
	set_combat_def(darkwizard) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 12
			attack = 5
			strength = 2
			defence = 5
			magic = 6
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 3
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
