package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MONKEY_ARCHER, Npcs.MONKEY_ARCHER_5273, Npcs.MONKEY_ARCHER_5274, Npcs.MONKEY_ARCHER_6794, Npcs.MONKEY_ARCHER_6813).forEach { monkeyarcher ->
	set_combat_def(monkeyarcher) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 50
			attack = 80
			strength = 80
			defence = 80
			magic = 1
			ranged = 110
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 50.00
		 }
	 }
}
