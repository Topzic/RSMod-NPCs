package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.KALPHITE_WORKER, Npcs.KALPHITE_WORKER_956, Npcs.KALPHITE_WORKER_961).forEach { kalphiteworker -> 
	set_combat_def(kalphiteworker) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 40
			attack = 20
			strength = 20
			defence = 20
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 5
			defenceSlash = 5
			defenceCrush = 1
			defenceMagic = 10
			defenceRanged = 10
		 }

		anims {
			attack = 6223
			block = 6227
			death = 6228
		 }

		slayerData {
			levelRequirement = 1
			xp = 40.00
		 }
	 }
}
