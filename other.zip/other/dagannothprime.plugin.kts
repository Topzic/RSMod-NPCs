package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DAGANNOTH_PRIME, Npcs.DAGANNOTH_PRIME_6497, Npcs.DAGANNOTH_PRIME_JR, Npcs.DAGANNOTH_PRIME_JR_6629).forEach { dagannothprime -> 
	set_combat_def(dagannothprime) {

		configs {
			attackSpeed = 4
			respawnDelay = 60
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 255
			attack = 255
			strength = 255
			defence = 255
			magic = 255
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 255
			defenceSlash = 255
			defenceCrush = 255
			defenceMagic = 255
			defenceRanged = 10
		 }

		anims {
			attack = 2854
			block = 2852
			death = 2856
		 }

		slayerData {
			levelRequirement = 0
			xp = 331.40
		 }
	 }
}
