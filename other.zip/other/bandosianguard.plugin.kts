package gg.rsmod.plugins.content.npcs.npcInfo.bandosianguard

arrayOf(Npcs.BANDOSIAN_GUARD).forEach { bandosianguard -> 
	set_combat_def(bandosianguard) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 130
			attack = 110
			strength = 115
			defence = 80
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 19
			magicDamageBonus = 0
			attackRanged = 19
			rangedStrengthBonus = 0
			defenceStab = 12
			defenceSlash = 14
			defenceCrush = 13
			defenceMagic = 5
			defenceRanged = 13
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
