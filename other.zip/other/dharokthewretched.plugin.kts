package gg.rsmod.plugins.content.npcs.npcInfo.dharokthewretched

arrayOf(Npcs.DHAROK_THE_WRETCHED).forEach { dharokthewretched -> 
	set_combat_def(dharokthewretched) {

		configs {
			attackSpeed = 7
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 100
			attack = 100
			strength = 100
			defence = 100
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 252
			defenceSlash = 250
			defenceCrush = 244
			defenceMagic = 11
			defenceRanged = 249
		 }

		anims {
			attack = 2067
			block = 2079
			death = 4167
		 }

		slayerData {
			levelRequirement = 1
			xp = 20.00
		 }
	 }
}
