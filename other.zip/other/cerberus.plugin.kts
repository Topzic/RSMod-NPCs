package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CERBERUS, Npcs.CERBERUS_5863, Npcs.CERBERUS_5866).forEach { cerberus -> 
	set_combat_def(cerberus) {

		configs {
			attackSpeed = 6
			respawnDelay = 3
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 600
			attack = 220
			strength = 220
			defence = 100
			magic = 220
			ranged = 220
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 50
			magicDamageBonus = 0
			attackRanged = 50
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 100
			defenceCrush = 25
			defenceMagic = 200
			defenceRanged = 200
		 }

		anims {
			attack = 4491
			block = 4489
			death = 4495
		 }

		slayerData {
			levelRequirement = 91
			xp = 690.00
		 }
	 }
}
