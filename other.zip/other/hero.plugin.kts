package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.HERO_3295).forEach { hero ->
	set_combat_def(hero) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 82
			attack = 54
			strength = 55
			defence = 54
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 20
			magicDamageBonus = 0
			attackRanged = 20
			rangedStrengthBonus = 0
			defenceStab = 87
			defenceSlash = 84
			defenceCrush = 76
			defenceMagic = 10
			defenceRanged = 79
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 273.30
		 }
	 }
}
