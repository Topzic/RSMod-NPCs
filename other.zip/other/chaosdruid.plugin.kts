package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.CHAOS_DRUID).forEach { chaosdruid ->
	set_combat_def(chaosdruid) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 20
			attack = 8
			strength = 8
			defence = 12
			magic = 10
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 425
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 20.00
		 }
	 }
}
