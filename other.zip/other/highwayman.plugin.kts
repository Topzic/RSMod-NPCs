package gg.rsmod.plugins.content.npcs.npcInfo.highwayman

arrayOf(Npcs.HIGHWAYMAN, Npcs.HIGHWAYMAN_519).forEach { highwayman -> 
	set_combat_def(highwayman) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 13
			attack = 2
			strength = 2
			defence = 2
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 6
			strengthBonus = 7
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 3
			defenceCrush = 2
			defenceMagic = 0
			defenceRanged = 2
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
