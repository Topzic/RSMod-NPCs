package gg.rsmod.plugins.content.npcs.npcInfo.other

															arrayOf(Npcs.BLACK_DRAGON, Npcs.BLACK_DRAGON_253, Npcs.BLACK_DRAGON_254, Npcs.BLACK_DRAGON_255, Npcs.BLACK_DRAGON_256, Npcs.BLACK_DRAGON_257, Npcs.BLACK_DRAGON_258, Npcs.BLACK_DRAGON_259, Npcs.BLACK_DRAGON_7861, Npcs.BLACK_DRAGON_7862, Npcs.BLACK_DRAGON_7863, Npcs.BLACK_DRAGON_8084, Npcs.BLACK_DRAGON_8085).forEach { blackdragon ->
	set_combat_def(blackdragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 190
			attack = 200
			strength = 200
			defence = 200
			magic = 100
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 60
			defenceRanged = 50
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 0
			xp = 195.00
		 }
	 }
}
