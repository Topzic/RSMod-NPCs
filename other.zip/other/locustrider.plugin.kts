package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.LOCUST_RIDER, Npcs.LOCUST_RIDER_796, Npcs.LOCUST_RIDER_800, Npcs.LOCUST_RIDER_801).forEach { locustrider -> 
	set_combat_def(locustrider) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 90
			attack = 105
			strength = 90
			defence = 50
			magic = 1
			ranged = 90
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 80
			rangedStrengthBonus = 80
			defenceStab = 50
			defenceSlash = 90
			defenceCrush = 50
			defenceMagic = 34
			defenceRanged = 66
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 925.00
		 }
	 }
}
