package gg.rsmod.plugins.content.npcs.npcInfo.balfrugkreeyath

arrayOf(Npcs.BALFRUG_KREEYATH).forEach { balfrugkreeyath -> 
	set_combat_def(balfrugkreeyath) {

		configs {
			attackSpeed = 5
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 161
			attack = 115
			strength = 60
			defence = 153
			magic = 150
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 10
			defenceRanged = 0
		 }

		anims {
			attack = 4630
			block = 65
			death = 67
		 }

		slayerData {
			levelRequirement = 1
			xp = 161.00
		 }
	 }
}
