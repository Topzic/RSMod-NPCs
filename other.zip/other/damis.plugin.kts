package gg.rsmod.plugins.content.npcs.npcInfo.damis

arrayOf(Npcs.DAMIS, Npcs.DAMIS_683, Npcs.DAMIS_HARD, Npcs.DAMIS_HARD_1135, Npcs.DAMIS_6346, Npcs.DAMIS_6347).forEach { damis -> 
	set_combat_def(damis) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 90
			attack = 90
			strength = 90
			defence = 90
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 80
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 60
			defenceSlash = 60
			defenceCrush = 60
			defenceMagic = 60
			defenceRanged = 60
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
