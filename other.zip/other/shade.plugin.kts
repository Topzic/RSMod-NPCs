package gg.rsmod.plugins.content.npcs.npcInfo.shade

arrayOf(Npcs.SHADE, Npcs.SHADE_6740, Npcs.SHADE_7258).forEach { shade ->
	set_combat_def(shade) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 170
			attack = 130
			strength = 130
			defence = 130
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 0
			xp = 34.00
		 }
	 }
}
