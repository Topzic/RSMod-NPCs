package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DEVIANT_SPECTRE).forEach { deviantspectre -> 
	set_combat_def(deviantspectre) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 190
			attack = 1
			strength = 1
			defence = 90
			magic = 205
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 80
			defenceSlash = 80
			defenceCrush = 80
			defenceMagic = 0
			defenceRanged = 85
		 }

		anims {
			attack = 1507
			block = 1509
			death = 1508
		 }

		slayerData {
			levelRequirement = 60
			xp = 38.00
		 }
	 }
}
