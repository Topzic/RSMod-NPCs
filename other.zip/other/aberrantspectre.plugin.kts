package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.ABERRANT_SPECTRE_2, Npcs.ABERRANT_SPECTRE_3, Npcs.ABERRANT_SPECTRE_4, Npcs.ABERRANT_SPECTRE_5, Npcs.ABERRANT_SPECTRE_6, Npcs.ABERRANT_SPECTRE_7).forEach { aberrantspectre -> 
	set_combat_def(aberrantspectre) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 3
			searchDelay = 1
		 }

		stats {
			hitpoints = 90
			attack = 1
			strength = 1
			defence = 90
			magic = 105
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 20
			defenceMagic = 0
			defenceRanged = 15
		 }

		anims {
			attack = 1507
			block = 1509
			death = 1508
		 }

		slayerData {
			levelRequirement = 60
			xp = 18.00
		 }
	 }
}
