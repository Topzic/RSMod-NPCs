package gg.rsmod.plugins.content.npcs.npcInfo.icetrollking

arrayOf(Npcs.ICE_TROLL_KING, Npcs.ICE_TROLL_KING_HARD, Npcs.ICE_TROLL_KING_6356).forEach { icetrollking -> 
	set_combat_def(icetrollking) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 150
			attack = 100
			strength = 100
			defence = 80
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 60
			strengthBonus = 60
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 45
			defenceSlash = 45
			defenceCrush = 45
			defenceMagic = 2000
			defenceRanged = 2000
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 0
			xp = 161.00
		 }
	 }
}
