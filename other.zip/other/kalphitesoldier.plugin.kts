package gg.rsmod.plugins.content.npcs.npcInfo.kalphitesoldier

arrayOf(Npcs.KALPHITE_SOLDIER_138, Npcs.KALPHITE_SOLDIER_957, Npcs.KALPHITE_SOLDIER_958).forEach { kalphitesoldier -> 
	set_combat_def(kalphitesoldier) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 90
			attack = 70
			strength = 70
			defence = 70
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 25
			defenceSlash = 25
			defenceCrush = 5
			defenceMagic = 50
			defenceRanged = 50
		 }

		anims {
			attack = 6223
			block = 6227
			death = 6228
		 }

		slayerData {
			levelRequirement = 1
			xp = 90.00
		 }
	 }
}
