package gg.rsmod.plugins.content.npcs.npcInfo.jelly

arrayOf(Npcs.JELLY_437, Npcs.JELLY_438, Npcs.JELLY_439, Npcs.JELLY_440, Npcs.JELLY_441, Npcs.JELLY_442, Npcs.JELLY_7518, Npcs.JELLY_11241, Npcs.JELLY_11242, Npcs.JELLY_11243, Npcs.JELLY_11244, Npcs.JELLY_11245).forEach { jelly ->
	set_combat_def(jelly) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 75
			attack = 45
			strength = 45
			defence = 120
			magic = 45
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 1586
			block = 1585
			death = 1587
		 }

		slayerData {
			levelRequirement = 52
			xp = 75.00
		 }
	 }
}
