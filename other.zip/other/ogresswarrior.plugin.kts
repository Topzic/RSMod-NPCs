package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.OGRESS_WARRIOR, Npcs.OGRESS_WARRIOR_7990).forEach { ogresswarrior -> 
	set_combat_def(ogresswarrior) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 82
			attack = 68
			strength = 70
			defence = 82
			magic = 60
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 12
			defenceCrush = 12
			defenceMagic = 14
			defenceRanged = 16
		 }

		anims {
			attack = 359
			block = 360
			death = 361
		 }

		slayerData {
			levelRequirement = 0
			xp = 82.00
		 }
	 }
}
