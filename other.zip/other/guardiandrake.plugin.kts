package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.GUARDIAN_DRAKE, Npcs.GUARDIAN_DRAKE_10401).forEach { guardiandrake -> 
	set_combat_def(guardiandrake) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 630
			attack = 270
			strength = 280
			defence = 200
			magic = 240
			ranged = 300
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 40
			rangedStrengthBonus = 0
			defenceStab = 60
			defenceSlash = 100
			defenceCrush = 100
			defenceMagic = 20
			defenceRanged = 150
		 }

		anims {
			attack = 1
			block = 1
			death = 1
		 }

		slayerData {
			levelRequirement = 84
			xp = 724.50
		 }
	 }
}
