package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BLACK_BEAR).forEach { blackbear -> 
	set_combat_def(blackbear) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 25
			attack = 15
			strength = 16
			defence = 13
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 4925
			block = 4927
			death = 4929
		 }

		slayerData {
			levelRequirement = 1
			xp = 25.00
		 }
	 }
}
