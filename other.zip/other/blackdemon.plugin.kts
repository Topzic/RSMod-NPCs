package gg.rsmod.plugins.content.npcs.npcInfo.blackdemon

arrayOf(Npcs.BLACK_DEMON, Npcs.BLACK_DEMON_1432, Npcs.BLACK_DEMON_2048, Npcs.BLACK_DEMON_2049, Npcs.BLACK_DEMON_2050, Npcs.BLACK_DEMON_2051, Npcs.BLACK_DEMON_2052, Npcs.BLACK_DEMON_5874, Npcs.BLACK_DEMON_5875, Npcs.BLACK_DEMON_5876, Npcs.BLACK_DEMON_5877, Npcs.BLACK_DEMON_HARD, Npcs.BLACK_DEMON_6357, Npcs.BLACK_DEMON_7242, Npcs.BLACK_DEMON_7243, Npcs.BLACK_DEMON_7874, Npcs.BLACK_DEMON_7875, Npcs.BLACK_DEMON_7876).forEach { blackdemon -> 
	set_combat_def(blackdemon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 157
			attack = 145
			strength = 148
			defence = 152
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 10
			defenceRanged = 0
		 }

		anims {
			attack = 64
			block = 65
			death = 67
		 }

		slayerData {
			levelRequirement = 0
			xp = 157.00
		 }
	 }
}
