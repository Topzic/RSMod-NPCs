package gg.rsmod.plugins.content.npcs.npcInfo.gangboss

arrayOf(Npcs.GANG_BOSS, Npcs.GANG_BOSS_6901, Npcs.GANG_BOSS_6902, Npcs.GANG_BOSS_6903).forEach { gangboss -> 
	set_combat_def(gangboss) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 80
			attack = 1
			strength = 1
			defence = 70
			magic = 1
			ranged = 80
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 50
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 10
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
