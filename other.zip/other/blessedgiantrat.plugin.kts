package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BLESSED_GIANT_RAT, Npcs.BLESSED_GIANT_RAT_4535).forEach { blessedgiantrat -> 
	set_combat_def(blessedgiantrat) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 30
			attack = 5
			strength = 1
			defence = 1
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = -24
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 24
			defenceSlash = 24
			defenceCrush = 24
			defenceMagic = 24
			defenceRanged = 24
		 }

		anims {
			attack = 4933
			block = 4934
			death = 4935
		 }

		slayerData {
			levelRequirement = 0
			xp = 30.00
		 }
	 }
}
