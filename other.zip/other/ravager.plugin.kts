package gg.rsmod.plugins.content.npcs.npcInfo.ravager

arrayOf(Npcs.RAVAGER, Npcs.RAVAGER_1705, Npcs.RAVAGER_1706, Npcs.RAVAGER_1707, Npcs.RAVAGER_1708).forEach { ravager -> 
	set_combat_def(ravager) {

		configs {
			attackSpeed = 4
			respawnDelay = 78
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 23
			attack = 27
			strength = 57
			defence = 13
			magic = 0
			ranged = 0
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 3915
			block = 3916
			death = 3917
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
