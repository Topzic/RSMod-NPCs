package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.FLAMING_PYRELORD).forEach { flamingpyrelord -> 
	set_combat_def(flamingpyrelord) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 126
			attack = 98
			strength = 65
			defence = 52
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 18
			defenceSlash = 18
			defenceCrush = 18
			defenceMagic = 0
			defenceRanged = 18
		 }

		anims {
			attack = 1582
			block = 1581
			death = 1580
		 }

		slayerData {
			levelRequirement = 30
			xp = 125.00
		 }
	 }
}
