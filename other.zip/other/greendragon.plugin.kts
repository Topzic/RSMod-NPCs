package gg.rsmod.plugins.content.npcs.npcInfo.greendragon

arrayOf(Npcs.GREEN_DRAGON, Npcs.GREEN_DRAGON_261, Npcs.GREEN_DRAGON_262, Npcs.GREEN_DRAGON_263, Npcs.GREEN_DRAGON_264,  Npcs.GREEN_DRAGON_7868, Npcs.GREEN_DRAGON_7869, Npcs.GREEN_DRAGON_7870, Npcs.GREEN_DRAGON_8073, Npcs.GREEN_DRAGON_8076, Npcs.GREEN_DRAGON_8082).forEach { greendragon ->
	set_combat_def(greendragon) {

		configs {
			attackSpeed = 4
			respawnDelay = 15
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 75
			attack = 68
			strength = 68
			defence = 68
			magic = 68
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 40
			defenceCrush = 40
			defenceMagic = 30
			defenceRanged = 20
		 }

		anims {
			attack = 80
			block = 89
			death = 92
		 }

		slayerData {
			levelRequirement = 0
			xp = 75.00
		 }
	 }
}
