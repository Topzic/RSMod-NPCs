package gg.rsmod.plugins.content.npcs.npcInfo.abyssaldemon

arrayOf(Npcs.ABYSSAL_DEMON_124, Npcs.ABYSSAL_DEMON_415, Npcs.ABYSSAL_DEMON_416, Npcs.ABYSSAL_DEMON_7241, Npcs.ABYSSAL_DEMON_11239).forEach { abyssaldemon ->
	set_combat_def(abyssaldemon) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			aggroTimer = 0
			aggroMinutes = 0
			neverAggro()
		 }

		stats {
			hitpoints = 150
			attack = 97
			strength = 67
			defence = 135
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 20
			defenceMagic = 0
			defenceRanged = 20
		 }

		anims {
			attack = 1537
			block = 2309
			death = 1538
		 }

		slayerData {
			levelRequirement = 85
			xp = 150.00
		 }
	 }
}
