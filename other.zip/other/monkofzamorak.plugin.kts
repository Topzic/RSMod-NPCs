package gg.rsmod.plugins.content.npcs.npcInfo.monkofzamorak

arrayOf(Npcs.MONK_OF_ZAMORAK, Npcs.MONK_OF_ZAMORAK_528, Npcs.MONK_OF_ZAMORAK_529, Npcs.MONK_OF_ZAMORAK_3484, Npcs.MONK_OF_ZAMORAK_3485, Npcs.MONK_OF_ZAMORAK_3486, Npcs.MONK_OF_ZAMORAK_8400, Npcs.MONK_OF_ZAMORAK_8401, Npcs.MONK_OF_ZAMORAK_8698).forEach { monkofzamorak -> 
	set_combat_def(monkofzamorak) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 10
			attack = 8
			strength = 8
			defence = 12
			magic = 25
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 0
			defenceSlash = 0
			defenceCrush = 0
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 707
			block = 390
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
