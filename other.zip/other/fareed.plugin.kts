package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.FAREED, Npcs.FAREED_HARD, Npcs.FAREED_6348).forEach { fareed -> 
	set_combat_def(fareed) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 130
			attack = 190
			strength = 120
			defence = 135
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 120
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 100
			defenceSlash = 100
			defenceCrush = 100
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
