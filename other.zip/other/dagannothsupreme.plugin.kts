package gg.rsmod.plugins.content.npcs.npcInfo.dagannothsupreme

arrayOf(Npcs.DAGANNOTH_SUPREME, Npcs.DAGANNOTH_SUPREME_6496, Npcs.DAGANNOTH_SUPREME_JR, Npcs.DAGANNOTH_SUPREME_JR_6628).forEach { dagannothsupreme -> 
	set_combat_def(dagannothsupreme) {

		configs {
			attackSpeed = 4
			respawnDelay = 60
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			aggroTimer = 0
			aggroMinutes = 10
		 }

		stats {
			hitpoints = 255
			attack = 255
			strength = 255
			defence = 128
			magic = 255
			ranged = 255
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 10
			defenceMagic = 255
			defenceRanged = 550
		 }

		anims {
			attack = 2855
			block = 2852
			death = 2856
		 }

		slayerData {
			levelRequirement = 0
			xp = 255.00
		 }
	 }
}
