package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.BROODOO_VICTIM, Npcs.BROODOO_VICTIM_6409, Npcs.BROODOO_VICTIM_6410, Npcs.BROODOO_VICTIM_6411, Npcs.BROODOO_VICTIM_6412, Npcs.BROODOO_VICTIM_6413).forEach { broodoovictim -> 
	set_combat_def(broodoovictim) {

		configs {
			attackSpeed = 6
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 100
			attack = 0
			strength = 0
			defence = 26
			magic = 60
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 25
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 20
			defenceSlash = 20
			defenceCrush = 20
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 0.00
		 }
	 }
}
