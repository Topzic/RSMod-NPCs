package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.DESSOUS_HARD, Npcs.DESSOUS, Npcs.DESSOUS_3460, Npcs.DESSOUS_6344).forEach { dessous -> 
	set_combat_def(dessous) {

		configs {
			attackSpeed = 3
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 200
			attack = 99
			strength = 99
			defence = 99
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 50
			strengthBonus = 50
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 150
			defenceCrush = 150
			defenceMagic = 0
			defenceRanged = 0
		 }

		anims {
			attack = 422
			block = 424
			death = 836
		 }

		slayerData {
			levelRequirement = 0
			xp = 220.00
		 }
	 }
}
