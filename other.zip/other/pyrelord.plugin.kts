package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.PYRELORD, Npcs.PYRELORD_6795).forEach { pyrelord ->
	set_combat_def(pyrelord) {

		configs {
			attackSpeed = 4
			respawnDelay = 0
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 0
			searchDelay = 0
			
			
			neverAggro()
		 }

		stats {
			hitpoints = 80
			attack = 60
			strength = 40
			defence = 30
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 10
			defenceCrush = 10
			defenceMagic = 0
			defenceRanged = 10
		 }

		anims {
			attack = 0
			block = 0
			death = 0
		 }

		slayerData {
			levelRequirement = 30
			xp = 80.00
		 }
	 }
}
