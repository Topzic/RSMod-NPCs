package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.REANIMATED_ELF).forEach { reanimatedelf -> 
	set_combat_def(reanimatedelf) {

		configs {
			attackSpeed = 4
			respawnDelay = 1
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 35
			attack = 35
			strength = 36
			defence = 37
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 50
			defenceSlash = 70
			defenceCrush = 70
			defenceMagic = 60
			defenceRanged = 50
		 }

		anims {
			attack = 422
			block = 425
			death = 836
		 }

		slayerData {
			levelRequirement = 1
			xp = 754.00
		 }
	 }
}
