package gg.rsmod.plugins.content.npcs.npcInfo.other

arrayOf(Npcs.MAGIC_AXE, Npcs.MAGIC_AXE_7269).forEach { magicaxe -> 
	set_combat_def(magicaxe) {

		configs {
			attackSpeed = 4
			respawnDelay = 30
			poisonChance = 0.0
			venomChance = 0.0
		 }

		aggro {
			radius = 2
			searchDelay = 1
			
			
		 }

		stats {
			hitpoints = 44
			attack = 38
			strength = 38
			defence = 29
			magic = 1
			ranged = 1
		 }

		bonuses {
			attackBonus = 0
			strengthBonus = 0
			attackMagic = 0
			magicDamageBonus = 0
			attackRanged = 0
			rangedStrengthBonus = 0
			defenceStab = 10
			defenceSlash = 5
			defenceCrush = 15
			defenceMagic = 5
			defenceRanged = 10
		 }

		anims {
			attack = 185
			block = 186
			death = 188
		 }

		slayerData {
			levelRequirement = 0
			xp = 44.00
		 }
	 }
}
